-- =====================================================================
-- EducaTech — Migração 0001
-- Tabelas, funções de apoio, gatilhos e políticas de acesso (RLS).
--
-- Como usar: Supabase > SQL Editor > New query > cole TODO este arquivo > Run.
-- Convenção: nomes de tabelas/colunas em inglês (como no prompt do projeto);
-- textos exibidos ao usuário ficam em português na interface.
-- =====================================================================

-- ---------- Tipos ----------
create type public.user_role         as enum ('student', 'teacher', 'admin');
create type public.account_status    as enum ('active', 'pending', 'suspended');
create type public.activity_kind     as enum ('task', 'written');      -- task = marcar como concluída; written = resposta escrita
create type public.submission_status as enum ('submitted', 'graded');  -- entregue / corrigida

-- ---------- Tabelas ----------
create table public.schools (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(name) between 2 and 120),
  invite_code text not null unique
              default upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10)),
  created_at  timestamptz not null default now()
);

create table public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  full_name   text not null check (char_length(full_name) between 2 and 120),
  email       text not null,
  role        public.user_role not null default 'student',
  status      public.account_status not null default 'active',
  school_id   uuid references public.schools (id) on delete set null,
  grade_label text check (grade_label is null or char_length(grade_label) <= 40), -- ex.: "7º ano"
  created_at  timestamptz not null default now()
);

create table public.classes (
  id          uuid primary key default gen_random_uuid(),
  school_id   uuid not null references public.schools (id) on delete cascade,
  name        text not null check (char_length(name) between 2 and 80),
  grade_label text check (grade_label is null or char_length(grade_label) <= 40),
  join_code   text not null unique
              default upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10)),
  created_at  timestamptz not null default now()
);

create table public.class_members (
  class_id    uuid not null references public.classes (id) on delete cascade,
  user_id     uuid not null references public.profiles (id) on delete cascade,
  member_role text not null check (member_role in ('student', 'teacher')),
  joined_at   timestamptz not null default now(),
  primary key (class_id, user_id)
);
create index class_members_user_idx on public.class_members (user_id);

create table public.activities (
  id           uuid primary key default gen_random_uuid(),
  class_id     uuid not null references public.classes (id) on delete cascade,
  teacher_id   uuid not null references public.profiles (id) on delete cascade,
  subject      text not null check (char_length(subject) between 2 and 60),
  title        text not null check (char_length(title) between 3 and 140),
  instructions text not null check (char_length(instructions) between 1 and 5000),
  due_at       timestamptz not null,
  kind         public.activity_kind not null default 'task',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index activities_class_idx on public.activities (class_id, due_at);
create index activities_teacher_idx on public.activities (teacher_id);

create table public.submissions (
  id           uuid primary key default gen_random_uuid(),
  activity_id  uuid not null references public.activities (id) on delete cascade,
  student_id   uuid not null references public.profiles (id) on delete cascade,
  answer_text  text check (answer_text is null or char_length(answer_text) <= 5000),
  status       public.submission_status not null default 'submitted',
  submitted_at timestamptz not null default now(),
  unique (activity_id, student_id)
);
create index submissions_student_idx on public.submissions (student_id);

create table public.feedback (
  id            uuid primary key default gen_random_uuid(),
  submission_id uuid not null unique references public.submissions (id) on delete cascade,
  teacher_id    uuid not null references public.profiles (id) on delete cascade,
  comment       text not null check (char_length(comment) between 1 and 3000),
  review_topic  text check (review_topic is null or char_length(review_topic) <= 100),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table public.announcements (
  id         uuid primary key default gen_random_uuid(),
  class_id   uuid not null references public.classes (id) on delete cascade,
  teacher_id uuid not null references public.profiles (id) on delete cascade,
  title      text not null check (char_length(title) between 3 and 140),
  body       text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index announcements_class_idx on public.announcements (class_id, created_at desc);

create table public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles (id) on delete cascade,
  title      text not null,
  body       text,
  link       text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications (user_id, created_at desc);

create table public.study_goals (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles (id) on delete cascade,
  title       text not null check (char_length(title) between 3 and 140),
  subject     text check (subject is null or char_length(subject) <= 60),
  target_date date,
  done        boolean not null default false,
  created_at  timestamptz not null default now()
);
create index study_goals_user_idx on public.study_goals (user_id);

-- Controle de uso da IA (limite de requisições). Não guarda o conteúdo das conversas.
create table public.ai_requests (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now()
);
create index ai_requests_user_idx on public.ai_requests (user_id, created_at desc);

-- Eventos de segurança (sem senhas e sem conteúdo privado).
create table public.security_events (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid references public.profiles (id) on delete set null,
  actor_id   uuid,
  event      text not null,
  meta       jsonb,
  created_at timestamptz not null default now()
);
create index security_events_created_idx on public.security_events (created_at desc);

-- ---------- Funções de apoio (usadas pelas políticas) ----------
-- SECURITY DEFINER evita recursão infinita nas políticas. Todas validam auth.uid().

create function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p
                 where p.id = auth.uid() and p.role = 'admin' and p.status = 'active');
$$;

create function public.is_class_member(p_class uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.class_members cm
                 join public.profiles p on p.id = cm.user_id
                 where cm.class_id = p_class and cm.user_id = auth.uid() and p.status = 'active');
$$;

create function public.is_class_teacher(p_class uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.class_members cm
                 join public.profiles p on p.id = cm.user_id
                 where cm.class_id = p_class and cm.user_id = auth.uid()
                   and cm.member_role = 'teacher' and p.role = 'teacher' and p.status = 'active');
$$;

create function public.is_class_student(p_class uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.class_members cm
                 join public.profiles p on p.id = cm.user_id
                 where cm.class_id = p_class and cm.user_id = auth.uid()
                   and cm.member_role = 'student' and p.role = 'student' and p.status = 'active');
$$;

create function public.owns_activity(p_activity uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.activities a
                 where a.id = p_activity and a.teacher_id = auth.uid()
                   and public.is_class_teacher(a.class_id));
$$;

create function public.student_in_activity_class(p_activity uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.activities a
                 where a.id = p_activity and public.is_class_student(a.class_id));
$$;

create function public.owns_submission(p_submission uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.submissions s
                 where s.id = p_submission and public.owns_activity(s.activity_id));
$$;

create function public.can_read_submission(p_submission uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.submissions s
                 where s.id = p_submission
                   and (s.student_id = auth.uid() or public.owns_activity(s.activity_id)));
$$;

-- Quem pode ver o perfil de quem: o próprio usuário, administradores, professor <-> aluno da mesma turma.
-- Alunos NÃO veem perfis de outros alunos.
create function public.can_see_profile(p_target uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select p_target = auth.uid()
      or public.is_admin()
      or exists (
        select 1
        from public.class_members me
        join public.class_members other on other.class_id = me.class_id
        where me.user_id = auth.uid() and other.user_id = p_target
          and ((me.member_role = 'teacher' and other.member_role = 'student')
            or (me.member_role = 'student' and other.member_role = 'teacher'))
      );
$$;

-- ---------- Funções chamadas pelo aplicativo (RPC) ----------

-- Verifica se um código existe (usado no cadastro, antes de ter conta).
create function public.check_signup_code(p_code text, p_kind text) returns boolean
language sql stable security definer set search_path = public as $$
  select case
    when p_kind = 'teacher' then exists (select 1 from public.schools where invite_code = upper(trim(p_code)))
    else exists (select 1 from public.classes where join_code = upper(trim(p_code)))
  end;
$$;

-- Aluno entra em uma turma usando o código.
create function public.join_class_by_code(p_code text) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_role public.user_role;
  v_status public.account_status;
  v_class uuid;
begin
  select role, status into v_role, v_status from public.profiles where id = auth.uid();
  if v_role is distinct from 'student' or v_status is distinct from 'active' then
    raise exception 'Apenas alunos com conta ativa podem entrar em turmas.';
  end if;
  select id into v_class from public.classes where join_code = upper(trim(p_code));
  if v_class is null then
    raise exception 'Código de turma inválido.' using errcode = 'P0002';
  end if;
  insert into public.class_members (class_id, user_id, member_role)
  values (v_class, auth.uid(), 'student') on conflict do nothing;
  return v_class;
end $$;

-- Registro restrito de eventos de segurança (apenas uma lista fixa de eventos).
create function public.log_security_event(p_event text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  if p_event not in ('login', 'logout', 'password_changed', 'password_reset') then return; end if;
  insert into public.security_events (user_id, actor_id, event) values (auth.uid(), auth.uid(), p_event);
end $$;

-- ---------- Gatilhos ----------

-- Cria o perfil quando alguém se cadastra. O PAPEL NUNCA VEM DIRETO DO FORMULÁRIO:
-- só existe "aluno" (ativo) ou "professor" (pendente, aguardando aprovação). Admin nunca é criado aqui.
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_name    text := left(coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), 'Usuário'), 120);
  v_wanted  text := new.raw_user_meta_data ->> 'account_type';
  v_code    text := upper(trim(coalesce(new.raw_user_meta_data ->> 'code', '')));
  v_role    public.user_role := 'student';
  v_status  public.account_status := 'active';
  v_school  uuid;
  v_class   uuid;
begin
  if v_wanted = 'teacher' then
    v_role := 'teacher';
    v_status := 'pending';
    if v_code <> '' then
      select id into v_school from public.schools where invite_code = v_code;
    end if;
  elsif v_code <> '' then
    select id, school_id into v_class, v_school from public.classes where join_code = v_code;
  end if;

  insert into public.profiles (id, full_name, email, role, status, school_id)
  values (new.id, v_name, new.email, v_role, v_status, v_school);

  if v_role = 'student' and v_class is not null then
    insert into public.class_members (class_id, user_id, member_role) values (v_class, new.id, 'student');
  end if;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users for each row execute function public.handle_new_user();

-- Impede que usuários comuns alterem papel, e-mail ou situação da própria conta.
create function public.protect_profile_columns() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return new; end if;  -- SQL Editor / manutenção pelo servidor
  if new.id <> old.id or new.email <> old.email or new.role <> old.role or new.created_at <> old.created_at then
    raise exception 'Alteração não permitida.' using errcode = '42501';
  end if;
  if new.status <> old.status or new.school_id is distinct from old.school_id then
    if not public.is_admin() then
      raise exception 'Alteração não permitida.' using errcode = '42501';
    end if;
    if new.id = auth.uid() then
      raise exception 'Administradores não podem alterar a própria situação.' using errcode = '42501';
    end if;
  end if;
  return new;
end $$;

create trigger protect_profile before update on public.profiles
  for each row execute function public.protect_profile_columns();

-- Registra mudanças de situação da conta e avisa o professor aprovado.
create function public.on_profile_status_change() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status <> old.status then
    insert into public.security_events (user_id, actor_id, event, meta)
    values (new.id, auth.uid(), 'account_status_changed',
            jsonb_build_object('from', old.status, 'to', new.status));
    if old.status = 'pending' and new.status = 'active' then
      insert into public.notifications (user_id, title, body, link)
      values (new.id, 'Conta aprovada', 'Sua conta foi aprovada. Você já pode usar o painel.', '/painel');
    end if;
  end if;
  return new;
end $$;

create trigger profile_status_change after update on public.profiles
  for each row execute function public.on_profile_status_change();

-- Entregas: professor só muda o status; aluno não muda atividade/aluno.
create function public.protect_submission_columns() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return new; end if;
  if new.activity_id <> old.activity_id or new.student_id <> old.student_id then
    raise exception 'Alteração não permitida.' using errcode = '42501';
  end if;
  if auth.uid() <> old.student_id then
    if new.answer_text is distinct from old.answer_text or new.submitted_at <> old.submitted_at then
      raise exception 'Professores não podem alterar a resposta do aluno.' using errcode = '42501';
    end if;
  else
    new.submitted_at := now();
  end if;
  return new;
end $$;

create trigger protect_submission before update on public.submissions
  for each row execute function public.protect_submission_columns();

create function public.touch_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

create trigger activities_touch before update on public.activities
  for each row execute function public.touch_updated_at();
create trigger feedback_touch before update on public.feedback
  for each row execute function public.touch_updated_at();

-- Notificações automáticas (só destinatários corretos; sem dados privados de terceiros).
create function public.notify_new_activity() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.notifications (user_id, title, body, link)
  select cm.user_id, 'Nova atividade: ' || new.title, 'Matéria: ' || new.subject,
         '/aluno/atividades/' || new.id
  from public.class_members cm where cm.class_id = new.class_id and cm.member_role = 'student';
  return new;
end $$;
create trigger activities_notify_new after insert on public.activities
  for each row execute function public.notify_new_activity();

create function public.notify_due_change() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.due_at <> old.due_at then
    insert into public.notifications (user_id, title, body, link)
    select cm.user_id, 'Prazo alterado: ' || new.title, 'Matéria: ' || new.subject,
           '/aluno/atividades/' || new.id
    from public.class_members cm where cm.class_id = new.class_id and cm.member_role = 'student';
  end if;
  return new;
end $$;
create trigger activities_notify_due after update on public.activities
  for each row execute function public.notify_due_change();

create function public.notify_feedback() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.notifications (user_id, title, body, link)
  select s.student_id, 'Nova devolutiva: ' || a.title, 'Seu professor comentou sua atividade.',
         '/aluno/atividades/' || a.id
  from public.submissions s join public.activities a on a.id = s.activity_id
  where s.id = new.submission_id;
  return new;
end $$;
create trigger feedback_notify after insert on public.feedback
  for each row execute function public.notify_feedback();

create function public.notify_announcement() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.notifications (user_id, title, body, link)
  select cm.user_id, 'Aviso: ' || new.title, left(new.body, 140), '/aluno'
  from public.class_members cm where cm.class_id = new.class_id and cm.member_role = 'student';
  return new;
end $$;
create trigger announcements_notify after insert on public.announcements
  for each row execute function public.notify_announcement();

-- ---------- Row Level Security ----------
alter table public.schools         enable row level security;
alter table public.profiles        enable row level security;
alter table public.classes         enable row level security;
alter table public.class_members   enable row level security;
alter table public.activities      enable row level security;
alter table public.submissions     enable row level security;
alter table public.feedback        enable row level security;
alter table public.announcements   enable row level security;
alter table public.notifications   enable row level security;
alter table public.study_goals     enable row level security;
alter table public.ai_requests     enable row level security;
alter table public.security_events enable row level security;

-- schools: somente administradores
create policy schools_admin_all on public.schools for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- profiles
create policy profiles_select on public.profiles for select to authenticated
  using (public.can_see_profile(id));
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_admin())
  with check (id = auth.uid() or public.is_admin());

-- classes
create policy classes_admin_all on public.classes for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy classes_member_select on public.classes for select to authenticated
  using (public.is_class_member(id));

-- class_members
create policy members_admin_all on public.class_members for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy members_select_own on public.class_members for select to authenticated
  using (user_id = auth.uid());
create policy members_select_teacher on public.class_members for select to authenticated
  using (public.is_class_teacher(class_id));

-- activities
create policy activities_select on public.activities for select to authenticated
  using (public.is_class_member(class_id));
create policy activities_insert on public.activities for insert to authenticated
  with check (teacher_id = auth.uid() and public.is_class_teacher(class_id));
create policy activities_update on public.activities for update to authenticated
  using (teacher_id = auth.uid() and public.is_class_teacher(class_id))
  with check (teacher_id = auth.uid() and public.is_class_teacher(class_id));
create policy activities_delete on public.activities for delete to authenticated
  using (teacher_id = auth.uid() and public.is_class_teacher(class_id));

-- submissions
create policy submissions_select on public.submissions for select to authenticated
  using (student_id = auth.uid() or public.owns_activity(activity_id));
create policy submissions_insert on public.submissions for insert to authenticated
  with check (student_id = auth.uid() and status = 'submitted'
              and public.student_in_activity_class(activity_id));
create policy submissions_update_student on public.submissions for update to authenticated
  using (student_id = auth.uid() and status = 'submitted')
  with check (student_id = auth.uid() and status = 'submitted');
create policy submissions_update_teacher on public.submissions for update to authenticated
  using (public.owns_activity(activity_id))
  with check (public.owns_activity(activity_id));

-- feedback
create policy feedback_select on public.feedback for select to authenticated
  using (public.can_read_submission(submission_id));
create policy feedback_insert on public.feedback for insert to authenticated
  with check (teacher_id = auth.uid() and public.owns_submission(submission_id));
create policy feedback_update on public.feedback for update to authenticated
  using (teacher_id = auth.uid() and public.owns_submission(submission_id))
  with check (teacher_id = auth.uid() and public.owns_submission(submission_id));
create policy feedback_delete on public.feedback for delete to authenticated
  using (teacher_id = auth.uid() and public.owns_submission(submission_id));

-- announcements
create policy announcements_select on public.announcements for select to authenticated
  using (public.is_class_member(class_id));
create policy announcements_insert on public.announcements for insert to authenticated
  with check (teacher_id = auth.uid() and public.is_class_teacher(class_id));
create policy announcements_update on public.announcements for update to authenticated
  using (teacher_id = auth.uid() and public.is_class_teacher(class_id))
  with check (teacher_id = auth.uid() and public.is_class_teacher(class_id));
create policy announcements_delete on public.announcements for delete to authenticated
  using (teacher_id = auth.uid() and public.is_class_teacher(class_id));

-- notifications (criadas só pelos gatilhos; o usuário lê, marca como lida e apaga as suas)
create policy notifications_select on public.notifications for select to authenticated
  using (user_id = auth.uid());
create policy notifications_update on public.notifications for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy notifications_delete on public.notifications for delete to authenticated
  using (user_id = auth.uid());

-- study_goals
create policy goals_all on public.study_goals for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ai_requests
create policy ai_requests_select on public.ai_requests for select to authenticated
  using (user_id = auth.uid());
create policy ai_requests_insert on public.ai_requests for insert to authenticated
  with check (user_id = auth.uid());

-- security_events: só administradores leem; ninguém escreve diretamente
create policy security_events_admin_select on public.security_events for select to authenticated
  using (public.is_admin());

-- ---------- Permissões de execução e de tabela ----------
revoke all on all tables in schema public from anon;
revoke update on public.notifications from authenticated;
grant update (read_at) on public.notifications to authenticated;
revoke insert, update, delete on public.security_events from authenticated;

revoke execute on all functions in schema public from public, anon;
grant execute on function
  public.is_admin(), public.is_class_member(uuid), public.is_class_teacher(uuid),
  public.is_class_student(uuid), public.owns_activity(uuid),
  public.student_in_activity_class(uuid), public.owns_submission(uuid),
  public.can_read_submission(uuid), public.can_see_profile(uuid),
  public.join_class_by_code(text), public.log_security_event(text)
  to authenticated;
-- O cadastro precisa conferir o código antes de existir uma conta:
grant execute on function public.check_signup_code(text, text) to anon, authenticated;
