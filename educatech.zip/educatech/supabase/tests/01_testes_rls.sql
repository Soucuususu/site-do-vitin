\set ON_ERROR_STOP off
\pset pager off
-- ===== preparação (como superusuário: auth.uid() nulo) =====
insert into public.schools(name) values ('Escola Teste');
insert into public.classes(school_id,name) select id,'7A' from public.schools;
insert into public.classes(school_id,name) select id,'8B' from public.schools;
select join_code as code7a from public.classes where name='7A' \gset
insert into auth.users(id,email,raw_user_meta_data) values
 ('00000000-0000-0000-0000-0000000000a1','admin@x.com','{"full_name":"Admin","account_type":"admin"}'),
 ('00000000-0000-0000-0000-0000000000b1','prof@x.com','{"full_name":"Profa Ativa","account_type":"teacher"}'),
 ('00000000-0000-0000-0000-0000000000b2','prof2@x.com','{"full_name":"Prof Pendente","account_type":"teacher"}'),
 ('00000000-0000-0000-0000-0000000000c1','aluno1@x.com',jsonb_build_object('full_name','Aluno Um','account_type','student','code',:'code7a')),
 ('00000000-0000-0000-0000-0000000000c2','aluno2@x.com',jsonb_build_object('full_name','Aluno Dois','account_type','student','code',:'code7a')),
 ('00000000-0000-0000-0000-0000000000c3','aluno3@x.com','{"full_name":"Aluno Tres","account_type":"student"}');
update public.profiles set role='admin' where id='00000000-0000-0000-0000-0000000000a1';
update public.profiles set status='active' where id='00000000-0000-0000-0000-0000000000b1';
insert into public.class_members(class_id,user_id,member_role) select id,'00000000-0000-0000-0000-0000000000b1','teacher' from public.classes where name='7A';
\echo '--- 1) papel pedido "admin" no cadastro virou:'
select email, role, status from public.profiles order by email;

\echo '--- 2) PROFESSORA ATIVA cria atividade (deve funcionar)'
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000b1';
insert into public.activities(class_id,teacher_id,subject,title,instructions,due_at,kind)
 select id,'00000000-0000-0000-0000-0000000000b1','Matemática','Equações','Resolva a lista',now()+interval '2 days','written' from public.classes where name='7A';
\echo '--- 3) professora tenta criar atividade na turma 8B (não é dela) -> deve FALHAR'
insert into public.activities(class_id,teacher_id,subject,title,instructions,due_at)
 select id,'00000000-0000-0000-0000-0000000000b1','Mat','Invasao','x',now() from public.classes where name='8B';
reset role;

\echo '--- 4) professor PENDENTE tenta criar atividade -> deve FALHAR'
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000b2';
insert into public.activities(class_id,teacher_id,subject,title,instructions,due_at)
 select id,'00000000-0000-0000-0000-0000000000b2','Mat','Fake','x',now() from public.classes where name='7A';
reset role;

\echo '--- 5) notificações geradas para os 2 alunos da 7A (esperado 2)'
select count(*) from public.notifications where title like 'Nova atividade%';

\echo '--- 6) ALUNO 1 ve atividades (1), ve perfis (so ele + professora), nao ve aluno2'
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000c1';
select count(*) as atividades from public.activities;
select full_name from public.profiles order by 1;
\echo '--- 7) aluno1 tenta virar admin / professor / ativar -> deve FALHAR'
update public.profiles set role='admin' where id=auth.uid();
update public.profiles set status='active', school_id=null where id=auth.uid();
\echo '--- 7b) aluno1 altera o próprio nome (deve funcionar)'
update public.profiles set full_name='Aluno Um Silva' where id=auth.uid();
\echo '--- 8) aluno1 entrega atividade (funciona)'
insert into public.submissions(activity_id,student_id,answer_text) select id, auth.uid(), 'x=4' from public.activities;
\echo '--- 8b) aluno1 tenta marcar a própria entrega como corrigida -> não deve alterar nenhuma linha (UPDATE 0)'
update public.submissions set status='graded' where student_id=auth.uid();
\echo '--- 8c) aluno1 tenta entregar em nome do aluno2 -> deve FALHAR'
insert into public.submissions(activity_id,student_id,answer_text) select id,'00000000-0000-0000-0000-0000000000c2','fraude' from public.activities;
reset role;

\echo '--- 9) ALUNO 2 nao ve a entrega do aluno1 (esperado 0)'
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000c2';
select count(*) as entregas_visiveis from public.submissions;
reset role;

\echo '--- 10) ALUNO 3 (sem turma) nao ve atividades nem entregas (0 e 0)'
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000c3';
select (select count(*) from public.activities) a, (select count(*) from public.submissions) s;
\echo '--- 10b) aluno3 entra com código da 7A (funciona) e depois com código inválido (falha)'
select public.join_class_by_code(:'code7a') is not null as entrou;
select public.join_class_by_code('ZZZZZZZZZZ');
select count(*) as atividades_agora from public.activities;
reset role;

\echo '--- 11) PROFESSORA corrige: ve a entrega, cria devolutiva, marca corrigida; tenta alterar resposta -> FALHA'
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000b1';
select count(*) as entregas from public.submissions;
update public.submissions set answer_text='adulterada';
insert into public.feedback(submission_id,teacher_id,comment,review_topic) select id, auth.uid(), 'Bom trabalho','Equações do 1º grau' from public.submissions;
update public.submissions set status='graded';
reset role;
\echo '--- 11b) aluno1 recebeu notificação de devolutiva (1) e ve a devolutiva; aluno2 nao (0)'
select count(*) from public.notifications where user_id='00000000-0000-0000-0000-0000000000c1' and title like 'Nova devolutiva%';
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000c1';
select count(*) as devolutivas_aluno1 from public.feedback;
reset role;
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000c2';
select count(*) as devolutivas_aluno2 from public.feedback;
\echo '--- 11c) aluno1 ja corrigida: nao consegue reeditar (UPDATE 0)'
reset role;
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000c1';
update public.submissions set answer_text='trocando depois' ;
reset role;

\echo '--- 12) ADMIN aprova professor pendente (funciona), mas NAO vê atividades (0) e não suspende a si mesmo'
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000a1';
update public.profiles set status='active' where id='00000000-0000-0000-0000-0000000000b2';
update public.profiles set status='suspended' where id=auth.uid();
select count(*) as atividades_do_admin from public.activities;
select event, meta from public.security_events;
reset role;

\echo '--- 13) professor suspenso perde acesso (0 atividades)'
update public.profiles set status='suspended' where id='00000000-0000-0000-0000-0000000000b1';
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000b1';
select count(*) from public.activities;
reset role;

\echo '--- 14) ANON nao lê nada'
set role anon; select count(*) from public.profiles;
select public.check_signup_code('ZZZ','student');
select public.is_admin();
reset role;
\echo '--- 15) usuário comum nao lê/escreve security_events e nao altera titulo de notificação'
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000c1';
select count(*) as eventos_visiveis from public.security_events;
insert into public.security_events(event) values ('forjado');
update public.notifications set title='hack';
update public.notifications set read_at=now();
reset role;
