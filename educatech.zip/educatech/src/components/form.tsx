"use client";

import { createContext, useActionState, useContext, useId, useState, type ReactNode } from "react";
import { useFormStatus } from "react-dom";
import { AlertCircle, CheckCircle2, Eye, EyeOff } from "lucide-react";
import type { Estado } from "@/lib/tipos";

type Acao = (anterior: Estado, dados: FormData) => Promise<Estado>;
interface Contexto { erros: Record<string, string>; valores: Record<string, string> }
const FormContexto = createContext<Contexto>({ erros: {}, valores: {} });

const CAMPOS_SECRETOS = /password|senha|confirm|current/i;

/**
 * Formulário com estados de erro e sucesso.
 * - Mostra a mensagem geral no topo (role="alert" / "status", lida por leitores de tela).
 * - Mantém o que o usuário digitou quando há erro de validação (exceto senhas).
 */
export function FormAcao({ action, children, className = "space-y-5" }: { action: Acao; children: ReactNode; className?: string }) {
  const [estado, enviar] = useActionState(
    async (anterior: Estado & { valores?: Record<string, string> }, dados: FormData) => {
      const r = await action(anterior, dados);
      const valores: Record<string, string> = {};
      if (!r.ok) {
        dados.forEach((v, k) => { if (typeof v === "string" && !CAMPOS_SECRETOS.test(k)) valores[k] = v; });
      }
      return { ...r, valores };
    },
    {} as Estado & { valores?: Record<string, string> },
  );

  return (
    <form action={enviar} className={className} noValidate>
      {estado.mensagem && (
        <div
          role={estado.ok ? "status" : "alert"}
          className={`flex items-start gap-2 rounded-lg border px-4 py-3 text-sm font-bold ${
            estado.ok ? "border-verde-700/30 bg-verde-50 text-verde-700" : "border-vermelho-700/30 bg-vermelho-50 text-vermelho-700"
          }`}
        >
          {estado.ok ? <CheckCircle2 aria-hidden className="mt-0.5 size-4 shrink-0" /> : <AlertCircle aria-hidden className="mt-0.5 size-4 shrink-0" />}
          <span>{estado.mensagem}</span>
        </div>
      )}
      <FormContexto.Provider value={{ erros: estado.erros ?? {}, valores: estado.valores ?? {} }}>
        {children}
      </FormContexto.Provider>
    </form>
  );
}

interface BaseProps { name: string; label: string; ajuda?: string; required?: boolean; defaultValue?: string }

function useCampo(name: string, defaultValue?: string) {
  const id = useId();
  const { erros, valores } = useContext(FormContexto);
  const erro = erros[name];
  return {
    id, erro, valor: valores[name] ?? defaultValue ?? "",
    descrito: [erro ? `${id}-erro` : "", `${id}-ajuda`].filter(Boolean).join(" "),
  };
}

function Rotulo({ id, label, required }: { id: string; label: string; required?: boolean }) {
  return (
    <label htmlFor={id} className="rotulo">
      {label}{required && <span aria-hidden className="text-vermelho-700"> *</span>}
      {required && <span className="sr-only"> (obrigatório)</span>}
    </label>
  );
}

function Mensagens({ id, ajuda, erro }: { id: string; ajuda?: string; erro?: string }) {
  return (
    <>
      {ajuda && <p id={`${id}-ajuda`} className="ajuda">{ajuda}</p>}
      {erro && <p id={`${id}-erro`} className="erro-campo">{erro}</p>}
    </>
  );
}

export function Campo(props: BaseProps & { type?: string; autoComplete?: string; placeholder?: string; maxLength?: number; inputMode?: "text" | "email" | "numeric" }) {
  const { name, label, ajuda, required, defaultValue, type = "text", ...resto } = props;
  const c = useCampo(name, defaultValue);
  return (
    <div>
      <Rotulo id={c.id} label={label} required={required} />
      <input id={c.id} name={name} type={type} defaultValue={c.valor} className="campo" required={required}
        aria-invalid={c.erro ? true : undefined} aria-describedby={c.descrito} {...resto} />
      <Mensagens id={c.id} ajuda={ajuda} erro={c.erro} />
    </div>
  );
}

export function CampoSenha({ name, label, ajuda, required, autoComplete }: Omit<BaseProps, "defaultValue"> & { autoComplete: string }) {
  const c = useCampo(name);
  const [visivel, setVisivel] = useState(false);
  return (
    <div>
      <Rotulo id={c.id} label={label} required={required} />
      <div className="relative">
        <input id={c.id} name={name} type={visivel ? "text" : "password"} className="campo pr-12" required={required}
          autoComplete={autoComplete} aria-invalid={c.erro ? true : undefined} aria-describedby={c.descrito} />
        <button type="button" onClick={() => setVisivel((v) => !v)} aria-pressed={visivel}
          aria-label={visivel ? "Ocultar senha" : "Mostrar senha"}
          className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-cinza-600 hover:text-azul-700">
          {visivel ? <EyeOff aria-hidden className="size-5" /> : <Eye aria-hidden className="size-5" />}
        </button>
      </div>
      <Mensagens id={c.id} ajuda={ajuda} erro={c.erro} />
    </div>
  );
}

export function AreaTexto({ name, label, ajuda, required, defaultValue, rows = 5, maxLength }: BaseProps & { rows?: number; maxLength?: number }) {
  const c = useCampo(name, defaultValue);
  return (
    <div>
      <Rotulo id={c.id} label={label} required={required} />
      <textarea id={c.id} name={name} rows={rows} defaultValue={c.valor} maxLength={maxLength} className="campo" required={required}
        aria-invalid={c.erro ? true : undefined} aria-describedby={c.descrito} />
      <Mensagens id={c.id} ajuda={ajuda} erro={c.erro} />
    </div>
  );
}

export function Selecao({ name, label, ajuda, required, defaultValue, opcoes, vazio }: BaseProps & { opcoes: { valor: string; rotulo: string }[]; vazio?: string }) {
  const c = useCampo(name, defaultValue);
  return (
    <div>
      <Rotulo id={c.id} label={label} required={required} />
      <select id={c.id} name={name} defaultValue={c.valor} className="campo" required={required}
        aria-invalid={c.erro ? true : undefined} aria-describedby={c.descrito}>
        {vazio !== undefined && <option value="">{vazio}</option>}
        {opcoes.map((o) => <option key={o.valor} value={o.valor}>{o.rotulo}</option>)}
      </select>
      <Mensagens id={c.id} ajuda={ajuda} erro={c.erro} />
    </div>
  );
}

/** Botão de envio: mostra "Aguarde…" enquanto o servidor responde. */
export function BotaoEnviar({ children, className = "botao botao-primario", aguarde = "Aguarde…" }: { children: ReactNode; className?: string; aguarde?: string }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className={className} disabled={pending} aria-disabled={pending}>
      {pending ? aguarde : children}
    </button>
  );
}
