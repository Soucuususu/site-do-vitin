import type { ReactNode } from "react";
import { AlertCircle, CheckCircle2, Info, TriangleAlert } from "lucide-react";
import type { Tom } from "@/lib/formato";

const TONS: Record<Tom, string> = {
  ok: "bg-verde-50 text-verde-700 border-verde-700/25",
  alerta: "bg-ambar-50 text-ambar-700 border-ambar-700/25",
  erro: "bg-vermelho-50 text-vermelho-700 border-vermelho-700/25",
  info: "bg-azul-50 text-azul-800 border-azul-200",
  neutro: "bg-cinza-100 text-cinza-700 border-cinza-200",
};

export function Etiqueta({ tom = "neutro", children }: { tom?: Tom; children: ReactNode }) {
  return <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-bold ${TONS[tom]}`}>{children}</span>;
}

export function Aviso({ tom = "info", titulo, children }: { tom?: Tom; titulo?: string; children?: ReactNode }) {
  const Icone = tom === "ok" ? CheckCircle2 : tom === "erro" ? AlertCircle : tom === "alerta" ? TriangleAlert : Info;
  return (
    <div role={tom === "erro" ? "alert" : "status"} className={`flex items-start gap-3 rounded-xl border px-4 py-3 text-sm ${TONS[tom]}`}>
      <Icone aria-hidden className="mt-0.5 size-5 shrink-0" />
      <div>{titulo && <p className="font-bold">{titulo}</p>}{children && <div>{children}</div>}</div>
    </div>
  );
}

export function TituloPagina({ titulo, descricao, acoes }: { titulo: string; descricao?: string; acoes?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl sm:text-3xl">{titulo}</h1>
        {descricao && <p className="mt-1 max-w-prose text-cinza-600">{descricao}</p>}
      </div>
      {acoes && <div className="flex flex-wrap gap-2">{acoes}</div>}
    </div>
  );
}

export function Secao({ titulo, acao, children, className = "" }: { titulo: string; acao?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`painel ${className}`}>
      <div className="flex items-center justify-between gap-3 border-b border-cinza-200 px-5 py-3">
        <h2 className="text-lg">{titulo}</h2>
        {acao}
      </div>
      <div className="painel-corpo">{children}</div>
    </section>
  );
}

export function EstadoVazio({ titulo, children }: { titulo: string; children?: ReactNode }) {
  return (
    <div className="rounded-lg border border-dashed border-cinza-300 bg-cinza-50 px-5 py-8 text-center">
      <p className="font-bold text-cinza-900">{titulo}</p>
      {children && <div className="mx-auto mt-1 max-w-md text-sm text-cinza-600">{children}</div>}
    </div>
  );
}

export function Progresso({ valor, rotulo }: { valor: number; rotulo: string }) {
  const v = Math.max(0, Math.min(100, Math.round(valor)));
  return (
    <div>
      <div className="mb-1 flex justify-between text-sm"><span className="font-bold">{rotulo}</span><span>{v}%</span></div>
      <div role="progressbar" aria-label={rotulo} aria-valuenow={v} aria-valuemin={0} aria-valuemax={100} className="h-2.5 overflow-hidden rounded-full bg-cinza-200">
        <div className="h-full rounded-full bg-azul-600" style={{ width: `${v}%` }} />
      </div>
    </div>
  );
}

export function Numero({ valor, rotulo }: { valor: number | string; rotulo: string }) {
  return (
    <div>
      <p className="text-3xl font-bold text-azul-900">{valor}</p>
      <p className="text-sm text-cinza-600">{rotulo}</p>
    </div>
  );
}
