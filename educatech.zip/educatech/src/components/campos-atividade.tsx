import { Campo, AreaTexto, Selecao } from "@/components/form";
import type { Atividade } from "@/lib/tipos";
import { paraInputLocal } from "@/lib/formato";

export function CamposAtividade({ atividade, turmas }: { atividade?: Atividade; turmas?: { id: string; name: string }[] }) {
  return (
    <>
      {turmas && <Selecao name="class_id" label="Turma" required vazio="Escolha a turma" opcoes={turmas.map((t) => ({ valor: t.id, rotulo: t.name }))} />}
      <Campo name="subject" label="Matéria" required maxLength={60} defaultValue={atividade?.subject} />
      <Campo name="title" label="Título" required maxLength={140} defaultValue={atividade?.title} />
      <AreaTexto name="instructions" label="Instruções" required rows={6} maxLength={5000} defaultValue={atividade?.instructions} />
      <Selecao name="kind" label="Como o aluno entrega?" required defaultValue={atividade?.kind ?? "written"}
        opcoes={[{ valor: "written", rotulo: "Resposta escrita" }, { valor: "task", rotulo: "Apenas marcar como concluída" }]} />
      <Campo name="due_at" label="Prazo (horário de Brasília)" type="datetime-local" required defaultValue={atividade ? paraInputLocal(atividade.due_at) : undefined} />
    </>
  );
}
