"use client";

import { useEffect, useRef, useState } from "react";
import { Send, Sparkles, User } from "lucide-react";

interface Mensagem { role: "user" | "assistant"; content: string }

const ATALHOS = [
  "Explique de outro jeito, por favor.",
  "Crie 3 exercícios de prática sobre isso.",
  "Faça um resumo do que conversamos.",
];

export function AssistenteChat({ temaInicial = "" }: { temaInicial?: string }) {
  const [mensagens, setMensagens] = useState<Mensagem[]>([]);
  const [texto, setTexto] = useState(temaInicial ? `Quero estudar: ${temaInicial}. Pode me ajudar a começar?` : "");
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState("");
  const [demo, setDemo] = useState<boolean | null>(null);
  const fim = useRef<HTMLDivElement>(null);

  useEffect(() => { fim.current?.scrollIntoView({ block: "end" }); }, [mensagens, carregando]);

  async function enviar(conteudo: string) {
    const limpo = conteudo.trim();
    if (!limpo || carregando) return;
    const novas: Mensagem[] = [...mensagens, { role: "user", content: limpo }];
    setMensagens(novas);
    setTexto("");
    setErro("");
    setCarregando(true);
    try {
      const r = await fetch("/api/assistente", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mensagens: novas.slice(-16) }),
      });
      const dados = await r.json().catch(() => ({}));
      if (!r.ok) {
        setErro(dados.erro ?? "Não foi possível falar com o assistente agora. Tente de novo em instantes.");
      } else {
        setDemo(Boolean(dados.modoDemonstrativo));
        setMensagens([...novas, { role: "assistant", content: String(dados.resposta ?? "") }]);
      }
    } catch {
      setErro("Sem conexão com o servidor. Verifique sua internet e tente de novo.");
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="painel flex flex-col">
      <div className="min-h-72 flex-1 space-y-4 p-4 sm:p-5" role="log" aria-live="polite" aria-label="Conversa com o Assistente EducaTech">
        {mensagens.length === 0 && (
          <div className="rounded-lg bg-azul-50 p-4 text-sm text-azul-900">
            <p className="font-bold">Oi! Eu sou o Assistente EducaTech.</p>
            <p className="mt-1">Conte qual é a sua dúvida e o que você já tentou. Eu ajudo você a pensar no caminho, em vez de só entregar a resposta.</p>
          </div>
        )}
        {mensagens.map((m, i) => (
          <div key={i} className={`flex gap-3 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
            <span aria-hidden className={`flex size-8 shrink-0 items-center justify-center rounded-full ${m.role === "user" ? "bg-cinza-200 text-cinza-700" : "bg-azul-600 text-white"}`}>
              {m.role === "user" ? <User className="size-4" /> : <Sparkles className="size-4" />}
            </span>
            <div className={`max-w-[85%] whitespace-pre-wrap rounded-xl px-4 py-2.5 text-[0.95rem] ${m.role === "user" ? "bg-azul-600 text-white" : "bg-cinza-100 text-cinza-900"}`}>
              <span className="sr-only">{m.role === "user" ? "Você: " : "Assistente: "}</span>
              {m.content}
            </div>
          </div>
        ))}
        {carregando && <p className="text-sm text-cinza-600" role="status">O assistente está pensando…</p>}
        <div ref={fim} />
      </div>

      {demo && (
        <p className="border-t border-ambar-700/25 bg-ambar-50 px-4 py-2 text-sm font-bold text-ambar-700">
          Modo demonstrativo: estas respostas são pré-escritas. A IA real ainda não está conectada.
        </p>
      )}
      {erro && <p role="alert" className="border-t border-vermelho-700/25 bg-vermelho-50 px-4 py-2 text-sm font-bold text-vermelho-700">{erro}</p>}

      <div className="border-t border-cinza-200 p-4">
        {mensagens.length > 0 && (
          <div className="mb-3 flex flex-wrap gap-2">
            {ATALHOS.map((a) => (
              <button key={a} type="button" onClick={() => enviar(a)} disabled={carregando} className="botao botao-secundario botao-pequeno">{a}</button>
            ))}
          </div>
        )}
        <form onSubmit={(e) => { e.preventDefault(); enviar(texto); }} className="flex flex-col gap-2 sm:flex-row sm:items-end">
          <div className="flex-1">
            <label htmlFor="pergunta" className="rotulo">Sua pergunta</label>
            <textarea id="pergunta" rows={2} maxLength={2000} value={texto} onChange={(e) => setTexto(e.target.value)} className="campo"
              placeholder="Ex.: Não entendi como resolver 2x + 6 = 14"
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); enviar(texto); } }} />
          </div>
          <button type="submit" className="botao botao-primario" disabled={carregando || !texto.trim()}>
            <Send aria-hidden className="size-4" />Enviar
          </button>
        </form>
        <p className="ajuda">O assistente pode errar: confirme com seu professor. Não escreva dados pessoais (endereço, telefone, senhas). As conversas não ficam salvas.</p>
      </div>
    </div>
  );
}
