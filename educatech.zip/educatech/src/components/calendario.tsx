import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { chaveDia } from "@/lib/formato";
import { EstadoVazio } from "./ui";

export interface ItemCalendario { id: string; titulo: string; materia: string; prazo: string; href: string }

const MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
const SEMANA = ["domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado"];

export function mesDaUrl(valor?: string) {
  const m = /^(\d{4})-(\d{2})$/.exec(valor ?? "");
  if (m && Number(m[2]) >= 1 && Number(m[2]) <= 12) return { ano: Number(m[1]), mes: Number(m[2]) };
  const hoje = chaveDia(new Date().toISOString());
  return { ano: Number(hoje.slice(0, 4)), mes: Number(hoje.slice(5, 7)) };
}

const rotuloMes = (ano: number, mes: number) => `${ano}-${String(mes).padStart(2, "0")}`;

export function Calendario({ itens, ano, mes, base }: { itens: ItemCalendario[]; ano: number; mes: number; base: string }) {
  const hoje = chaveDia(new Date().toISOString());
  const porDia = new Map<string, ItemCalendario[]>();
  for (const i of itens) {
    const k = chaveDia(i.prazo);
    porDia.set(k, [...(porDia.get(k) ?? []), i]);
  }

  const diasNoMes = new Date(Date.UTC(ano, mes, 0)).getUTCDate();
  const inicio = new Date(Date.UTC(ano, mes - 1, 1)).getUTCDay();
  const celulas: (number | null)[] = [...Array(inicio).fill(null), ...Array.from({ length: diasNoMes }, (_, i) => i + 1)];
  while (celulas.length % 7) celulas.push(null);
  const semanas = Array.from({ length: celulas.length / 7 }, (_, i) => celulas.slice(i * 7, i * 7 + 7));

  const anterior = mes === 1 ? rotuloMes(ano - 1, 12) : rotuloMes(ano, mes - 1);
  const proximo = mes === 12 ? rotuloMes(ano + 1, 1) : rotuloMes(ano, mes + 1);
  const chave = (d: number) => `${rotuloMes(ano, mes)}-${String(d).padStart(2, "0")}`;
  const diasComItens = Array.from({ length: diasNoMes }, (_, i) => i + 1).filter((d) => porDia.has(chave(d)));
  const hora = (iso: string) => new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" }).format(new Date(iso));

  return (
    <div>
      <div className="mb-4 flex items-center justify-between gap-3">
        <Link href={`${base}?mes=${anterior}`} className="botao botao-secundario botao-pequeno" aria-label="Mês anterior"><ChevronLeft aria-hidden className="size-4" />Anterior</Link>
        <h2 className="text-lg capitalize">{MESES[mes - 1]} de {ano}</h2>
        <Link href={`${base}?mes=${proximo}`} className="botao botao-secundario botao-pequeno" aria-label="Próximo mês">Próximo<ChevronRight aria-hidden className="size-4" /></Link>
      </div>

      {/* Celular: agenda em lista */}
      <div className="md:hidden">
        {diasComItens.length === 0 ? <EstadoVazio titulo="Nenhum prazo neste mês." /> : (
          <ul className="space-y-3">
            {diasComItens.map((d) => (
              <li key={d} className="painel painel-corpo">
                <p className="font-bold capitalize">{d} de {MESES[mes - 1]} · {SEMANA[new Date(Date.UTC(ano, mes - 1, d)).getUTCDay()]}</p>
                <ul className="mt-2 space-y-1">
                  {porDia.get(chave(d))!.map((i) => (
                    <li key={i.id}><Link href={i.href} className="link">{i.titulo}</Link> <span className="text-sm text-cinza-600">· {i.materia} · até {hora(i.prazo)}</span></li>
                  ))}
                </ul>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Tablet e computador: grade mensal */}
      <div className="hidden overflow-x-auto md:block">
        <table className="w-full table-fixed border-collapse overflow-hidden rounded-xl border border-cinza-200 bg-white">
          <caption className="sr-only">Calendário de {MESES[mes - 1]} de {ano} com os prazos das atividades</caption>
          <thead>
            <tr>{SEMANA.map((s) => <th key={s} scope="col" className="border-b border-cinza-200 bg-cinza-50 p-2 text-sm font-bold capitalize text-cinza-700"><abbr title={s} className="no-underline">{s.slice(0, 3)}</abbr></th>)}</tr>
          </thead>
          <tbody>
            {semanas.map((sem, i) => (
              <tr key={i}>
                {sem.map((d, j) => {
                  const lista = d ? porDia.get(chave(d)) ?? [] : [];
                  const eHoje = d !== null && chave(d) === hoje;
                  return (
                    <td key={j} className={`h-28 border border-cinza-200 p-1.5 align-top ${d ? "" : "bg-cinza-50"}`}>
                      {d && (
                        <>
                          <span className={`inline-flex size-6 items-center justify-center rounded-full text-sm ${eHoje ? "bg-azul-600 font-bold text-white" : "text-cinza-700"}`}>
                            {d}{eHoje && <span className="sr-only"> (hoje)</span>}
                          </span>
                          <ul className="mt-1 space-y-1">
                            {lista.map((it) => (
                              <li key={it.id}><Link href={it.href} className="block truncate rounded bg-azul-50 px-1.5 py-0.5 text-xs font-bold text-azul-800 hover:bg-azul-100" title={`${it.titulo} — ${it.materia}`}>{it.titulo}</Link></li>
                            ))}
                          </ul>
                        </>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
