import Link from "next/link";
import { Logo } from "./logo";

export function Rodape() {
  return (
    <footer className="border-t border-cinza-200 bg-white">
      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-10 sm:px-6 md:grid-cols-[1.5fr_1fr]">
        <div>
          <Logo />
          <p className="mt-3 max-w-md text-sm text-cinza-600">
            Projeto desenvolvido para o Desafio Liga Jovem. O EducaTech é uma ferramenta de apoio à educação e não substitui o trabalho dos professores.
          </p>
        </div>
        <nav aria-label="Rodapé" className="text-sm">
          <ul className="space-y-2">
            <li><Link href="/entrar" className="link">Entrar</Link></li>
            <li><Link href="/criar-conta" className="link">Criar conta</Link></li>
            <li><a href="#seguranca" className="link">Segurança e acessibilidade</a></li>
          </ul>
        </nav>
      </div>
      <p className="border-t border-cinza-200 px-4 py-4 text-center text-xs text-cinza-600">
        Versão de demonstração · Coletamos o mínimo de dados pessoais necessário para o funcionamento da plataforma.
      </p>
    </footer>
  );
}
