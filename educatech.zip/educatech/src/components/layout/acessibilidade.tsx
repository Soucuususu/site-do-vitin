"use client";

import { useEffect, useState } from "react";

const CHAVE_FONTE = "educatech:fonte";
const CHAVE_CONTRASTE = "educatech:contraste";
const TAMANHOS = [100, 112.5, 125, 150];

/** Ajuste do tamanho do texto e alto contraste. Fica salvo só neste navegador. */
export function Acessibilidade() {
  const [indice, setIndice] = useState(0);
  const [contraste, setContraste] = useState(false);

  useEffect(() => {
    try {
      const f = Number(localStorage.getItem(CHAVE_FONTE));
      const i = TAMANHOS.indexOf(f);
      if (i >= 0) setIndice(i);
      setContraste(localStorage.getItem(CHAVE_CONTRASTE) === "alto");
    } catch { /* armazenamento indisponível */ }
  }, []);

  function aplicarFonte(i: number) {
    const novo = Math.max(0, Math.min(TAMANHOS.length - 1, i));
    setIndice(novo);
    document.documentElement.style.fontSize = `${TAMANHOS[novo]}%`;
    try { localStorage.setItem(CHAVE_FONTE, String(TAMANHOS[novo])); } catch { /* ignora */ }
  }
  function alternarContraste() {
    const novo = !contraste;
    setContraste(novo);
    if (novo) document.documentElement.dataset.contraste = "alto";
    else delete document.documentElement.dataset.contraste;
    try { localStorage.setItem(CHAVE_CONTRASTE, novo ? "alto" : "normal"); } catch { /* ignora */ }
  }

  const base = "botao botao-leve botao-pequeno border-cinza-300";
  return (
    <div role="group" aria-label="Opções de acessibilidade" className="flex flex-wrap items-center gap-1.5">
      <button type="button" className={base} onClick={() => aplicarFonte(indice - 1)} disabled={indice === 0} aria-label="Diminuir o tamanho do texto">A−</button>
      <button type="button" className={base} onClick={() => aplicarFonte(0)} aria-label="Tamanho padrão do texto">A</button>
      <button type="button" className={base} onClick={() => aplicarFonte(indice + 1)} disabled={indice === TAMANHOS.length - 1} aria-label="Aumentar o tamanho do texto">A+</button>
      <button type="button" className={`${base} ${contraste ? "bg-azul-50 text-azul-800" : ""}`} onClick={alternarContraste} aria-pressed={contraste}>
        Alto contraste
      </button>
    </div>
  );
}
