import type { ReactNode } from "react";
import { LogOut } from "lucide-react";
import { sair } from "@/lib/acoes/auth";
import { rotuloPapel } from "@/lib/formato";
import type { Perfil } from "@/lib/tipos";
import { criarClienteServidor } from "@/lib/supabase/server";
import { MenuApp, type ItemMenu } from "./menu-app";

const MENUS: Record<Perfil["role"], ItemMenu[]> = {
  student: [
    { href: "/aluno", rotulo: "Início", icone: "inicio", raiz: true },
    { href: "/aluno/atividades", rotulo: "Atividades", icone: "atividades" },
    { href: "/aluno/estudos", rotulo: "Meus estudos", icone: "estudos" },
    { href: "/aluno/assistente", rotulo: "Assistente EducaTech", icone: "assistente" },
    { href: "/aluno/calendario", rotulo: "Calendário", icone: "calendario" },
    { href: "/notificacoes", rotulo: "Notificações", icone: "notificacoes" },
    { href: "/configuracoes", rotulo: "Configurações", icone: "configuracoes" },
  ],
  teacher: [
    { href: "/professor", rotulo: "Início", icone: "inicio", raiz: true },
    { href: "/professor/turmas", rotulo: "Turmas", icone: "turmas" },
    { href: "/professor/atividades", rotulo: "Atividades", icone: "atividades" },
    { href: "/professor/avisos", rotulo: "Avisos", icone: "avisos" },
    { href: "/professor/calendario", rotulo: "Calendário", icone: "calendario" },
    { href: "/notificacoes", rotulo: "Notificações", icone: "notificacoes" },
    { href: "/configuracoes", rotulo: "Configurações", icone: "configuracoes" },
  ],
  admin: [
    { href: "/admin", rotulo: "Visão geral", icone: "admin", raiz: true },
    { href: "/admin/estrutura", rotulo: "Escolas e turmas", icone: "estrutura" },
    { href: "/notificacoes", rotulo: "Notificações", icone: "notificacoes" },
    { href: "/configuracoes", rotulo: "Configurações", icone: "configuracoes" },
  ],
};

export async function AppShell({ perfil, children }: { perfil: Perfil; children: ReactNode }) {
  const supabase = await criarClienteServidor();
  const { count } = await supabase.from("notifications").select("id", { count: "exact", head: true }).is("read_at", null);

  return (
    <div className="min-h-screen lg:flex">
      <a href="#conteudo" className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:font-bold">
        Ir para o conteúdo
      </a>
      <MenuApp
        itens={MENUS[perfil.role]}
        nome={perfil.full_name}
        papel={rotuloPapel[perfil.role]}
        naoLidas={count ?? 0}
        sair={
          <form action={sair}>
            <button type="submit" className="botao botao-secundario botao-pequeno w-full"><LogOut aria-hidden className="size-4" />Sair da conta</button>
          </form>
        }
      />
      <main id="conteudo" tabIndex={-1} className="mx-auto w-full min-w-0 max-w-5xl flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
        {children}
      </main>
    </div>
  );
}
