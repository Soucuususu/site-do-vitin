"use client";

import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bell, BookOpen, Building2, CalendarDays, ClipboardList, Home, Megaphone, Menu, Settings, ShieldCheck, Sparkles, Users, X,
} from "lucide-react";
import { Logo } from "./logo";
import { Acessibilidade } from "./acessibilidade";

const ICONES = {
  inicio: Home, atividades: ClipboardList, estudos: BookOpen, assistente: Sparkles, calendario: CalendarDays,
  notificacoes: Bell, configuracoes: Settings, turmas: Users, avisos: Megaphone, admin: ShieldCheck, estrutura: Building2,
} as const;

export interface ItemMenu { href: string; rotulo: string; icone: keyof typeof ICONES; raiz?: boolean }

export function MenuApp({ itens, nome, papel, naoLidas, sair }: { itens: ItemMenu[]; nome: string; papel: string; naoLidas: number; sair: ReactNode }) {
  const caminho = usePathname();
  const [aberto, setAberto] = useState(false);
  useEffect(() => { setAberto(false); }, [caminho]);

  const ativo = (i: ItemMenu) => (i.raiz ? caminho === i.href : caminho === i.href || caminho.startsWith(i.href + "/"));

  return (
    <>
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-cinza-200 bg-white px-4 py-2 lg:hidden">
        <Logo href="/painel" />
        <button type="button" className="botao botao-secundario botao-pequeno" aria-expanded={aberto} aria-controls="menu-principal" onClick={() => setAberto((a) => !a)}>
          {aberto ? <X aria-hidden className="size-4" /> : <Menu aria-hidden className="size-4" />}
          Menu
        </button>
      </header>

      <aside id="menu-principal" className={`${aberto ? "flex" : "hidden"} flex-col gap-5 border-b border-cinza-200 bg-white p-4 lg:sticky lg:top-0 lg:flex lg:h-screen lg:w-64 lg:shrink-0 lg:overflow-y-auto lg:border-b-0 lg:border-r`}>
        <div className="hidden lg:block"><Logo href="/painel" /></div>
        <nav aria-label="Menu principal">
          <ul className="space-y-1">
            {itens.map((i) => {
              const Icone = ICONES[i.icone];
              const atual = ativo(i);
              return (
                <li key={i.href}>
                  <Link href={i.href} aria-current={atual ? "page" : undefined}
                    className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-bold ${atual ? "bg-azul-50 text-azul-800" : "text-cinza-700 hover:bg-cinza-100"}`}>
                    <Icone aria-hidden className="size-5 shrink-0" />
                    <span className="flex-1">{i.rotulo}</span>
                    {i.icone === "notificacoes" && naoLidas > 0 && (
                      <span className="rounded-full bg-azul-600 px-2 py-0.5 text-xs text-white">
                        {naoLidas}<span className="sr-only"> não lidas</span>
                      </span>
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
        <div className="mt-auto space-y-3 border-t border-cinza-200 pt-4">
          <div>
            <p className="truncate text-sm font-bold text-cinza-900">{nome}</p>
            <p className="text-xs text-cinza-600">{papel}</p>
          </div>
          <Acessibilidade />
          {sair}
        </div>
      </aside>
    </>
  );
}
