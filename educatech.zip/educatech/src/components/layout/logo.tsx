import Link from "next/link";
import { GraduationCap } from "lucide-react";

export function Logo({ href = "/" }: { href?: string }) {
  return (
    <Link href={href} className="inline-flex items-center gap-2.5" aria-label="EducaTech — página inicial">
      <span className="flex size-9 items-center justify-center rounded-lg bg-azul-600 text-white">
        <GraduationCap aria-hidden className="size-5" />
      </span>
      <span className="text-xl font-bold tracking-tight text-azul-900">Educa<span className="text-azul-600">Tech</span></span>
    </Link>
  );
}
