import { NextResponse, type NextRequest } from "next/server";
import { atualizarSessao } from "@/lib/supabase/proxy";

// Rotas que exigem login. A verificação do PERFIL (aluno/professor/admin) acontece
// nos layouts/páginas e, principalmente, no banco de dados (RLS).
const PRIVADAS = ["/aluno", "/professor", "/admin", "/configuracoes", "/notificacoes", "/painel", "/pendente", "/redefinir-senha", "/api/assistente"];

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Ajuda para iniciantes: se o .env.local não foi preenchido, explica o que fazer.
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
    if (pathname === "/" || pathname === "/configurar") return NextResponse.next();
    return NextResponse.rewrite(new URL("/configurar", request.url));
  }

  const { resposta, user } = await atualizarSessao(request);
  const privada = PRIVADAS.some((p) => pathname === p || pathname.startsWith(p + "/"));

  if (!user && privada) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ erro: "Faça login para continuar." }, { status: 401 });
    }
    return NextResponse.redirect(new URL("/entrar", request.url));
  }
  return resposta;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|woff2?)$).*)"],
};
