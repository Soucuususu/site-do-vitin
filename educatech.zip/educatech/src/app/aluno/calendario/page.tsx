import type { Metadata } from "next";
import { exigirSessao } from "@/lib/auth";
import { carregarAluno } from "@/lib/consultas";
import { Calendario, mesDaUrl } from "@/components/calendario";
import { TituloPagina } from "@/components/ui";

export const metadata: Metadata = { title: "Calendário" };

export default async function CalendarioAluno({ searchParams }: { searchParams: Promise<{ mes?: string }> }) {
  const { supabase, user } = await exigirSessao("student");
  const { mes } = await searchParams;
  const { ano, mes: m } = mesDaUrl(mes);
  const { atividades } = await carregarAluno(supabase, user.id);
  return (
    <>
      <TituloPagina titulo="Calendário" descricao="Prazos das atividades das suas turmas." />
      <Calendario ano={ano} mes={m} base="/aluno/calendario"
        itens={atividades.map((a) => ({ id: a.id, titulo: a.title, materia: a.subject, prazo: a.due_at, href: `/aluno/atividades/${a.id}` }))} />
    </>
  );
}
