import type { Metadata } from "next";
import Link from "next/link";
import { Sparkles, ArrowRight } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { carregarAluno, carregarAvisos } from "@/lib/consultas";
import { entrarNaTurma } from "@/lib/acoes/aluno";
import { dataHora, prazoRelativo, primeiroNome, statusAtividade } from "@/lib/formato";
import { Aviso, Etiqueta, EstadoVazio, Numero, Progresso, Secao } from "@/components/ui";
import { FormAcao, Campo, BotaoEnviar } from "@/components/form";

export const metadata: Metadata = { title: "Início" };

export default async function InicioAluno() {
  const { supabase, user, perfil } = await exigirSessao("student");
  const [{ atividades, entregas, turmas, erro }, avisos] = await Promise.all([carregarAluno(supabase, user.id), carregarAvisos(supabase)]);

  const pendentes = atividades.filter((a) => !entregas.has(a.id));
  const concluidas = atividades.filter((a) => entregas.has(a.id));
  const emAtraso = pendentes.filter((a) => new Date(a.due_at) < new Date());
  const proximos = pendentes.filter((a) => new Date(a.due_at) >= new Date()).slice(0, 5);
  const progresso = atividades.length ? (concluidas.length / atividades.length) * 100 : 0;

  return (
    <>
      <h1 className="text-2xl sm:text-3xl">Olá, {primeiroNome(perfil.full_name)}!</h1>
      <p className="mt-1 text-cinza-600">Veja o que precisa de atenção hoje.</p>

      {erro && <div className="mt-4"><Aviso tom="erro" titulo="Não foi possível carregar tudo.">Atualize a página em instantes.</Aviso></div>}

      {turmas.size === 0 && !erro && (
        <section className="painel painel-corpo mt-6">
          <h2 className="text-lg">Entre na sua turma</h2>
          <p className="mb-4 mt-1 text-sm text-cinza-600">Você ainda não está em nenhuma turma. Digite o código fornecido pela escola ou pelo professor.</p>
          <FormAcao action={entrarNaTurma} className="flex max-w-md flex-col gap-3 sm:flex-row sm:items-start">
            <div className="flex-1"><Campo name="code" label="Código da turma" maxLength={20} required /></div>
            <div className="sm:mt-6"><BotaoEnviar aguarde="Entrando…">Entrar na turma</BotaoEnviar></div>
          </FormAcao>
        </section>
      )}

      <section aria-label="Resumo" className="painel painel-corpo mt-6 grid gap-6 sm:grid-cols-[auto_auto_auto_1fr] sm:items-center">
        <Numero valor={pendentes.length} rotulo="pendentes" />
        <Numero valor={concluidas.length} rotulo="concluídas" />
        <Numero valor={emAtraso.length} rotulo="em atraso" />
        <Progresso valor={progresso} rotulo="Progresso das atividades" />
      </section>

      <section className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-xl bg-azul-900 p-5 text-white">
        <div className="flex items-start gap-3">
          <Sparkles aria-hidden className="mt-1 size-6 shrink-0 text-azul-200" />
          <div>
            <h2 className="text-lg !text-white">Está com dúvida?</h2>
            <p className="text-sm text-azul-100">O Assistente EducaTech ajuda você a entender o conteúdo, passo a passo.</p>
          </div>
        </div>
        <Link href="/aluno/assistente" className="botao bg-white text-azul-900 hover:bg-azul-50">Conversar com o assistente <ArrowRight aria-hidden className="size-4" /></Link>
      </section>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Secao titulo="Próximos prazos" acao={<Link href="/aluno/atividades" className="link text-sm">Ver todas</Link>}>
          {emAtraso.length === 0 && proximos.length === 0 ? (
            <EstadoVazio titulo="Nenhuma atividade pendente.">Quando o professor publicar novas atividades, elas aparecem aqui.</EstadoVazio>
          ) : (
            <ul className="divide-y divide-cinza-200">
              {[...emAtraso.slice(0, 3), ...proximos].map((a) => {
                const st = statusAtividade(a);
                return (
                  <li key={a.id} className="flex items-start justify-between gap-3 py-3 first:pt-0 last:pb-0">
                    <div>
                      <Link href={`/aluno/atividades/${a.id}`} className="font-bold text-azul-800 hover:underline">{a.title}</Link>
                      <p className="text-sm text-cinza-600">{a.subject} · {dataHora(a.due_at)} ({prazoRelativo(a.due_at)})</p>
                    </div>
                    <Etiqueta tom={st.tom}>{st.rotulo}</Etiqueta>
                  </li>
                );
              })}
            </ul>
          )}
        </Secao>

        <Secao titulo="Avisos dos professores">
          {avisos.length === 0 ? <EstadoVazio titulo="Nenhum aviso por enquanto." /> : (
            <ul className="space-y-4">
              {avisos.map((v) => (
                <li key={v.id}>
                  <p className="font-bold">{v.title}</p>
                  <p className="whitespace-pre-wrap text-sm text-cinza-700">{v.body}</p>
                  <p className="mt-1 text-xs text-cinza-600">{turmas.get(v.class_id)?.name} · {dataHora(v.created_at)}</p>
                </li>
              ))}
            </ul>
          )}
        </Secao>
      </div>
    </>
  );
}
