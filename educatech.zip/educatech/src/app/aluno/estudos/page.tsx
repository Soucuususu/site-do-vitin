import type { Metadata } from "next";
import Link from "next/link";
import { Check, RotateCcw, Sparkles, Trash2 } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { carregarAluno } from "@/lib/consultas";
import { criarMeta, alternarMeta, excluirMeta } from "@/lib/acoes/aluno";
import { dataCurta, dataHora } from "@/lib/formato";
import { Aviso, EstadoVazio, Secao, TituloPagina } from "@/components/ui";
import { FormAcao, Campo, BotaoEnviar } from "@/components/form";
import type { Devolutiva, Meta } from "@/lib/tipos";

export const metadata: Metadata = { title: "Meus estudos" };

export default async function Estudos() {
  const { supabase, user } = await exigirSessao("student");
  const [{ atividades, entregas }, metasRes, devRes] = await Promise.all([
    carregarAluno(supabase, user.id),
    supabase.from("study_goals").select("*").order("done").order("target_date", { ascending: true, nullsFirst: false }),
    supabase.from("feedback").select("*").not("review_topic", "is", null).order("created_at", { ascending: false }),
  ]);
  const metas = (metasRes.data ?? []) as Meta[];
  const devolutivas = (devRes.data ?? []) as Devolutiva[];
  const porAtividade = new Map(atividades.map((a) => [a.id, a]));
  const entregaPorId = new Map([...entregas.values()].map((e) => [e.id, e]));

  const revisar = devolutivas.map((d) => {
    const ent = entregaPorId.get(d.submission_id);
    return { d, atividade: ent ? porAtividade.get(ent.activity_id) : undefined };
  });
  const atrasadas = atividades.filter((a) => !entregas.has(a.id) && new Date(a.due_at) < new Date());
  const historico = atividades.filter((a) => entregas.has(a.id))
    .sort((x, y) => +new Date(entregas.get(y.id)!.submitted_at) - +new Date(entregas.get(x.id)!.submitted_at));

  return (
    <>
      <TituloPagina titulo="Meus estudos" descricao="Organize suas metas e veja o que vale a pena revisar." />
      <div className="space-y-6">
        <Secao titulo="Metas pessoais">
          <FormAcao action={criarMeta} className="mb-5 grid gap-3 sm:grid-cols-[2fr_1fr_1fr_auto] sm:items-start">
            <Campo name="title" label="Nova meta" required maxLength={140} />
            <Campo name="subject" label="Matéria (opcional)" maxLength={60} />
            <Campo name="target_date" label="Data (opcional)" type="date" />
            <div className="sm:mt-6"><BotaoEnviar aguarde="Salvando…">Adicionar</BotaoEnviar></div>
          </FormAcao>
          {metas.length === 0 ? <EstadoVazio titulo="Você ainda não criou metas.">Por exemplo: “Revisar frações até sexta-feira”.</EstadoVazio> : (
            <ul className="divide-y divide-cinza-200">
              {metas.map((m) => (
                <li key={m.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                  <div className={m.done ? "text-cinza-600 line-through" : ""}>
                    <p className="font-bold">{m.title}</p>
                    <p className="text-sm">{[m.subject, m.target_date && `até ${dataCurta(m.target_date)}`].filter(Boolean).join(" · ")}</p>
                  </div>
                  <div className="flex gap-2">
                    <form action={alternarMeta}>
                      <input type="hidden" name="id" value={m.id} /><input type="hidden" name="done" value={String(!m.done)} />
                      <button className="botao botao-secundario botao-pequeno">{m.done ? <><RotateCcw aria-hidden className="size-4" />Reabrir</> : <><Check aria-hidden className="size-4" />Concluir</>}</button>
                    </form>
                    <form action={excluirMeta}>
                      <input type="hidden" name="id" value={m.id} />
                      <button className="botao botao-perigo botao-pequeno" aria-label={`Excluir meta: ${m.title}`}><Trash2 aria-hidden className="size-4" />Excluir</button>
                    </form>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Secao>

        <Secao titulo="Conteúdos para revisar">
          <p className="mb-4 text-sm text-cinza-600">Estas indicações vêm dos comentários dos seus professores e das atividades que passaram do prazo.</p>
          {revisar.length === 0 && atrasadas.length === 0 ? (
            <EstadoVazio titulo="Nada para revisar agora.">Quando um professor sugerir uma revisão, ela aparecerá aqui.</EstadoVazio>
          ) : (
            <ul className="space-y-3">
              {revisar.map(({ d, atividade }) => (
                <li key={d.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg bg-cinza-50 p-4">
                  <div>
                    <p className="font-bold">{d.review_topic}</p>
                    {atividade && <p className="text-sm text-cinza-600">Sugerido em “{atividade.title}” · {atividade.subject}</p>}
                  </div>
                  <Link href={`/aluno/assistente?tema=${encodeURIComponent(d.review_topic ?? "")}`} className="botao botao-secundario botao-pequeno"><Sparkles aria-hidden className="size-4" />Estudar com o assistente</Link>
                </li>
              ))}
              {atrasadas.map((a) => (
                <li key={a.id} className="rounded-lg bg-ambar-50 p-4 text-ambar-700">
                  <p className="font-bold">Atividade em atraso: <Link href={`/aluno/atividades/${a.id}`} className="underline">{a.title}</Link></p>
                  <p className="text-sm">{a.subject} · prazo em {dataHora(a.due_at)}</p>
                </li>
              ))}
            </ul>
          )}
        </Secao>

        <Secao titulo="Histórico de atividades concluídas">
          {historico.length === 0 ? <EstadoVazio titulo="Nenhuma atividade concluída ainda." /> : (
            <ul className="divide-y divide-cinza-200">
              {historico.slice(0, 20).map((a) => (
                <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
                  <Link href={`/aluno/atividades/${a.id}`} className="font-bold text-azul-800 hover:underline">{a.title}</Link>
                  <span className="text-sm text-cinza-600">{a.subject} · enviada em {dataHora(entregas.get(a.id)!.submitted_at)}</span>
                </li>
              ))}
            </ul>
          )}
        </Secao>

        <Aviso tom="info" titulo="Sobre as recomendações">
          O EducaTech não ranqueia alunos nem cria diagnósticos automáticos. As sugestões de revisão vêm de indicações dos professores.
        </Aviso>
      </div>
    </>
  );
}
