import { exigirSessao } from "@/lib/auth";
import { AppShell } from "@/components/layout/shell";

export default async function LayoutAluno({ children }: { children: React.ReactNode }) {
  const { perfil } = await exigirSessao("student");
  return <AppShell perfil={perfil}>{children}</AppShell>;
}
