import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, MessageSquareText } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { enviarEntrega } from "@/lib/acoes/aluno";
import { dataHora, prazoRelativo, statusAtividade } from "@/lib/formato";
import { uuid } from "@/lib/validacao";
import { Aviso, Etiqueta, Secao } from "@/components/ui";
import { FormAcao, AreaTexto, BotaoEnviar } from "@/components/form";
import type { Atividade, Devolutiva, Entrega, Perfil } from "@/lib/tipos";

export const metadata: Metadata = { title: "Atividade" };

export default async function DetalheAtividade({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!uuid.safeParse(id).success) notFound();
  const { supabase, user } = await exigirSessao("student");

  // O banco só devolve a atividade se ela for de uma turma deste aluno.
  const { data } = await supabase.from("activities").select("*").eq("id", id).maybeSingle();
  const atividade = data as Atividade | null;
  if (!atividade) notFound();

  const [{ data: e }, { data: prof }] = await Promise.all([
    supabase.from("submissions").select("*").eq("activity_id", id).eq("student_id", user.id).maybeSingle(),
    supabase.from("profiles").select("full_name").eq("id", atividade.teacher_id).maybeSingle(),
  ]);
  const entrega = e as Entrega | null;
  const professor = prof as Pick<Perfil, "full_name"> | null;
  let devolutiva: Devolutiva | null = null;
  if (entrega) {
    const { data: d } = await supabase.from("feedback").select("*").eq("submission_id", entrega.id).maybeSingle();
    devolutiva = d as Devolutiva | null;
  }
  const st = statusAtividade(atividade, entrega ?? undefined);
  const corrigida = entrega?.status === "graded";

  return (
    <>
      <Link href="/aluno/atividades" className="link mb-4 inline-flex items-center gap-1 text-sm"><ArrowLeft aria-hidden className="size-4" />Voltar para atividades</Link>
      <div className="mb-6">
        <p className="text-xs font-bold uppercase tracking-wide text-azul-700">{atividade.subject}</p>
        <h1 className="text-2xl sm:text-3xl">{atividade.title}</h1>
        <p className="mt-2 flex flex-wrap items-center gap-3 text-sm text-cinza-600">
          <Etiqueta tom={st.tom}>{st.rotulo}</Etiqueta>
          <span>Prazo: {dataHora(atividade.due_at)} ({prazoRelativo(atividade.due_at)})</span>
          {professor && <span>Professor(a): {professor.full_name}</span>}
        </p>
      </div>

      <div className="space-y-6">
        <Secao titulo="Instruções"><p className="whitespace-pre-wrap">{atividade.instructions}</p></Secao>

        {devolutiva && (
          <section className="rounded-xl border border-azul-200 bg-azul-50 p-5" aria-labelledby="titulo-devolutiva">
            <h2 id="titulo-devolutiva" className="flex items-center gap-2 text-lg"><MessageSquareText aria-hidden className="size-5" />Devolutiva do professor</h2>
            <p className="mt-2 whitespace-pre-wrap">{devolutiva.comment}</p>
            {devolutiva.review_topic && <p className="mt-3 text-sm"><strong>Sugestão de revisão:</strong> {devolutiva.review_topic}</p>}
          </section>
        )}

        <Secao titulo={atividade.kind === "task" ? "Concluir atividade" : "Sua resposta"}>
          {corrigida ? (
            <>
              <Aviso tom="ok" titulo="Esta atividade já foi corrigida.">Não é mais possível alterar a entrega.</Aviso>
              {entrega?.answer_text && <p className="mt-4 whitespace-pre-wrap rounded-lg bg-cinza-50 p-4">{entrega.answer_text}</p>}
            </>
          ) : (
            <FormAcao action={enviarEntrega}>
              <input type="hidden" name="activity_id" value={atividade.id} />
              <AreaTexto name="answer_text" rows={atividade.kind === "task" ? 3 : 8} maxLength={5000}
                label={atividade.kind === "task" ? "Observação para o professor (opcional)" : "Escreva sua resposta"}
                required={atividade.kind === "written"} defaultValue={entrega?.answer_text ?? ""} />
              <BotaoEnviar aguarde="Enviando…">
                {atividade.kind === "task" ? (entrega ? "Atualizar observação" : "Marcar como concluída") : entrega ? "Atualizar resposta" : "Enviar resposta"}
              </BotaoEnviar>
              {entrega && <p className="ajuda">Você pode alterar a entrega até o professor corrigir.</p>}
            </FormAcao>
          )}
        </Secao>
      </div>
    </>
  );
}
