import type { Metadata } from "next";
import Link from "next/link";
import { exigirSessao } from "@/lib/auth";
import { carregarAluno } from "@/lib/consultas";
import { dataHora, prazoRelativo, statusAtividade } from "@/lib/formato";
import { Etiqueta, EstadoVazio, TituloPagina } from "@/components/ui";

export const metadata: Metadata = { title: "Atividades" };

const FILTROS = [
  { id: "pendentes", rotulo: "Pendentes" },
  { id: "concluidas", rotulo: "Concluídas" },
  { id: "todas", rotulo: "Todas" },
] as const;

export default async function Atividades({ searchParams }: { searchParams: Promise<{ filtro?: string }> }) {
  const { supabase, user } = await exigirSessao("student");
  const { filtro: f } = await searchParams;
  const filtro = FILTROS.some((x) => x.id === f) ? (f as (typeof FILTROS)[number]["id"]) : "pendentes";
  const { atividades, entregas, turmas } = await carregarAluno(supabase, user.id);

  const lista = atividades.filter((a) => (filtro === "todas" ? true : filtro === "pendentes" ? !entregas.has(a.id) : entregas.has(a.id)));
  if (filtro === "concluidas") lista.reverse();

  return (
    <>
      <TituloPagina titulo="Atividades" descricao="Atividades publicadas pelos professores das suas turmas." />
      <nav aria-label="Filtrar atividades" className="mb-5 flex flex-wrap gap-2">
        {FILTROS.map((x) => (
          <Link key={x.id} href={`/aluno/atividades?filtro=${x.id}`} aria-current={filtro === x.id ? "page" : undefined}
            className={`botao botao-pequeno ${filtro === x.id ? "botao-primario" : "botao-secundario"}`}>{x.rotulo}</Link>
        ))}
      </nav>
      {lista.length === 0 ? (
        <EstadoVazio titulo={filtro === "pendentes" ? "Você não tem atividades pendentes." : "Nenhuma atividade aqui."}>
          {atividades.length === 0 ? "Quando o professor publicar uma atividade para a sua turma, ela aparecerá aqui." : "Experimente outro filtro."}
        </EstadoVazio>
      ) : (
        <ul className="space-y-3">
          {lista.map((a) => {
            const st = statusAtividade(a, entregas.get(a.id));
            return (
              <li key={a.id}>
                <Link href={`/aluno/atividades/${a.id}`} className="painel flex flex-wrap items-center justify-between gap-3 p-4 hover:border-azul-500">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wide text-azul-700">{a.subject} · {turmas.get(a.class_id)?.name}</p>
                    <p className="text-lg font-bold text-cinza-900">{a.title}</p>
                    <p className="text-sm text-cinza-600">Prazo: {dataHora(a.due_at)} ({prazoRelativo(a.due_at)})</p>
                  </div>
                  <Etiqueta tom={st.tom}>{st.rotulo}</Etiqueta>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
