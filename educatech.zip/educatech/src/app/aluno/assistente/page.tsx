import type { Metadata } from "next";
import { exigirSessao } from "@/lib/auth";
import { configuracaoIA } from "@/lib/ia/assistente";
import { AssistenteChat } from "@/components/assistente-chat";
import { Aviso, TituloPagina } from "@/components/ui";

export const metadata: Metadata = { title: "Assistente EducaTech" };

export default async function Assistente({ searchParams }: { searchParams: Promise<{ tema?: string }> }) {
  await exigirSessao("student");
  const { tema } = await searchParams;
  const demonstrativo = configuracaoIA() === null;

  return (
    <>
      <TituloPagina titulo="Assistente EducaTech" descricao="Seu tutor de estudos: tira dúvidas, explica passo a passo e cria exercícios de prática." />
      {demonstrativo && (
        <div className="mb-5">
          <Aviso tom="alerta" titulo="Modo demonstrativo">
            A IA real ainda não está conectada neste ambiente. As respostas abaixo são pré-escritas, só para mostrar como o assistente funcionará.
          </Aviso>
        </div>
      )}
      <AssistenteChat temaInicial={(tema ?? "").slice(0, 100)} />
    </>
  );
}
