import type { Metadata } from "next";
import { exigirSessao } from "@/lib/auth";
import { alterarSituacao } from "@/lib/acoes/admin";
import { dataHora, rotuloPapel, rotuloSituacao } from "@/lib/formato";
import { BotaoEnviar } from "@/components/form";
import { Etiqueta, EstadoVazio, Numero, Secao, TituloPagina } from "@/components/ui";
import type { EventoSeguranca, Perfil, Escola } from "@/lib/tipos";

export const metadata: Metadata = { title: "Administração" };

const EVENTOS: Record<string, string> = {
  login: "Entrou na conta", logout: "Saiu da conta", password_changed: "Alterou a senha",
  password_reset: "Redefiniu a senha", account_status_changed: "Situação da conta alterada",
};

function BotaoSituacao({ id, status, rotulo, perigo }: { id: string; status: "active" | "suspended"; rotulo: string; perigo?: boolean }) {
  return (
    <form action={alterarSituacao}>
      <input type="hidden" name="id" value={id} /><input type="hidden" name="status" value={status} />
      <BotaoEnviar className={`botao botao-pequeno ${perigo ? "botao-perigo" : "botao-primario"}`} aguarde="Aguarde…">{rotulo}</BotaoEnviar>
    </form>
  );
}

export default async function PainelAdmin() {
  const { supabase } = await exigirSessao("admin");
  const [contas, escolas, eventos] = await Promise.all([
    supabase.from("profiles").select("*").neq("role", "admin").order("created_at", { ascending: false }).limit(200),
    supabase.from("schools").select("*"),
    supabase.from("security_events").select("*").order("created_at", { ascending: false }).limit(15),
  ]);
  const lista = (contas.data ?? []) as Perfil[];
  const nomeEscola = new Map(((escolas.data ?? []) as Escola[]).map((e) => [e.id, e.name]));
  const evs = (eventos.data ?? []) as EventoSeguranca[];

  const ids = [...new Set(evs.map((e) => e.user_id).filter(Boolean) as string[])];
  const { data: ps } = ids.length ? await supabase.from("profiles").select("id,full_name").in("id", ids) : { data: [] };
  const nomes = new Map((ps ?? []).map((p) => [p.id as string, p.full_name as string]));

  const pendentes = lista.filter((p) => p.role === "teacher" && p.status === "pending");
  const outras = lista.filter((p) => !pendentes.includes(p));

  return (
    <>
      <TituloPagina titulo="Administração" descricao="Aprove professores, resolva problemas de acesso e acompanhe o funcionamento." />
      <section aria-label="Resumo" className="painel painel-corpo mb-6 grid grid-cols-2 gap-6 sm:grid-cols-4">
        <Numero valor={pendentes.length} rotulo="professores aguardando" />
        <Numero valor={lista.filter((p) => p.role === "teacher" && p.status === "active").length} rotulo="professores ativos" />
        <Numero valor={lista.filter((p) => p.role === "student").length} rotulo="alunos" />
        <Numero valor={lista.filter((p) => p.status === "suspended").length} rotulo="contas suspensas" />
      </section>

      <div className="space-y-6">
        <Secao titulo="Professores aguardando aprovação">
          {pendentes.length === 0 ? <EstadoVazio titulo="Nenhum professor aguardando." /> : (
            <ul className="divide-y divide-cinza-200">
              {pendentes.map((p) => (
                <li key={p.id} className="flex flex-wrap items-center justify-between gap-3 py-3 first:pt-0 last:pb-0">
                  <div>
                    <p className="font-bold">{p.full_name}</p>
                    <p className="text-sm text-cinza-600">{p.email} · cadastro em {dataHora(p.created_at)}{p.school_id && ` · escola informada: ${nomeEscola.get(p.school_id) ?? "—"}`}</p>
                  </div>
                  <div className="flex gap-2">
                    <BotaoSituacao id={p.id} status="active" rotulo="Aprovar" />
                    <BotaoSituacao id={p.id} status="suspended" rotulo="Recusar" perigo />
                  </div>
                </li>
              ))}
            </ul>
          )}
          <p className="ajuda mt-3">Depois de aprovar, vincule o professor às turmas em “Escolas e turmas”.</p>
        </Secao>

        <Secao titulo="Contas de professores e alunos">
          {outras.length === 0 ? <EstadoVazio titulo="Nenhuma conta ainda." /> : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[34rem] text-left text-sm">
                <caption className="sr-only">Contas cadastradas</caption>
                <thead><tr className="border-b border-cinza-200"><th scope="col" className="py-2 pr-3">Nome</th><th scope="col" className="py-2 pr-3">Tipo</th><th scope="col" className="py-2 pr-3">Situação</th><th scope="col" className="py-2"><span className="sr-only">Ação</span></th></tr></thead>
                <tbody>
                  {outras.map((p) => (
                    <tr key={p.id} className="border-b border-cinza-100 align-middle">
                      <td className="py-2 pr-3"><p className="font-bold">{p.full_name}</p><p className="text-cinza-600">{p.email}</p></td>
                      <td className="py-2 pr-3">{rotuloPapel[p.role]}</td>
                      <td className="py-2 pr-3"><Etiqueta tom={p.status === "active" ? "ok" : p.status === "pending" ? "alerta" : "erro"}>{rotuloSituacao[p.status]}</Etiqueta></td>
                      <td className="py-2 text-right">
                        {p.status === "suspended"
                          ? <BotaoSituacao id={p.id} status="active" rotulo="Reativar" />
                          : <BotaoSituacao id={p.id} status="suspended" rotulo="Suspender" perigo />}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Secao>

        <Secao titulo="Eventos de segurança recentes">
          {evs.length === 0 ? <EstadoVazio titulo="Nenhum evento registrado." /> : (
            <ul className="divide-y divide-cinza-200 text-sm">
              {evs.map((e) => (
                <li key={e.id} className="flex flex-wrap justify-between gap-2 py-2">
                  <span><strong>{e.user_id ? nomes.get(e.user_id) ?? "Usuário" : "—"}</strong>: {EVENTOS[e.event] ?? e.event}
                    {e.event === "account_status_changed" && e.meta && ` (${rotuloSituacao[e.meta.from as keyof typeof rotuloSituacao] ?? e.meta.from} → ${rotuloSituacao[e.meta.to as keyof typeof rotuloSituacao] ?? e.meta.to})`}</span>
                  <span className="text-cinza-600">{dataHora(e.created_at)}</span>
                </li>
              ))}
            </ul>
          )}
          <p className="ajuda mt-3">Registramos apenas o tipo do evento e o horário. Nunca senhas nem conteúdo de atividades.</p>
        </Secao>
      </div>
    </>
  );
}
