import type { Metadata } from "next";
import { X } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { criarEscola, criarTurma, vincularProfessor, desvincularProfessor } from "@/lib/acoes/admin";
import { FormAcao, Campo, Selecao, BotaoEnviar } from "@/components/form";
import { EstadoVazio, Secao, TituloPagina } from "@/components/ui";
import type { Escola, MembroTurma, Perfil, Turma } from "@/lib/tipos";

export const metadata: Metadata = { title: "Escolas e turmas" };

export default async function Estrutura() {
  const { supabase } = await exigirSessao("admin");
  const [e, t, m, p] = await Promise.all([
    supabase.from("schools").select("*").order("name"),
    supabase.from("classes").select("*").order("name"),
    supabase.from("class_members").select("*").eq("member_role", "teacher"),
    supabase.from("profiles").select("*").eq("role", "teacher").eq("status", "active").order("full_name"),
  ]);
  const escolas = (e.data ?? []) as Escola[];
  const turmas = (t.data ?? []) as Turma[];
  const vinculos = (m.data ?? []) as MembroTurma[];
  const professores = (p.data ?? []) as Perfil[];

  return (
    <>
      <TituloPagina titulo="Escolas e turmas" descricao="Cadastre escolas e turmas e vincule os professores aprovados." />
      <div className="space-y-6">
        <Secao titulo="Escolas">
          <FormAcao action={criarEscola} className="mb-5 flex max-w-xl flex-col gap-3 sm:flex-row sm:items-start">
            <div className="flex-1"><Campo name="name" label="Nome da nova escola" required maxLength={120} /></div>
            <div className="sm:mt-6"><BotaoEnviar aguarde="Criando…">Criar escola</BotaoEnviar></div>
          </FormAcao>
          {escolas.length === 0 ? <EstadoVazio titulo="Nenhuma escola cadastrada." /> : (
            <ul className="divide-y divide-cinza-200">
              {escolas.map((s) => (
                <li key={s.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
                  <span className="font-bold">{s.name}</span>
                  <span className="text-sm">Código para professores: <code className="rounded bg-cinza-100 px-2 py-1 font-bold tracking-wider">{s.invite_code}</code></span>
                </li>
              ))}
            </ul>
          )}
        </Secao>

        <Secao titulo="Nova turma">
          {escolas.length === 0 ? <EstadoVazio titulo="Crie uma escola primeiro." /> : (
            <FormAcao action={criarTurma} className="grid max-w-3xl gap-3 sm:grid-cols-[1.2fr_1fr_1fr_auto] sm:items-start">
              <Selecao name="school_id" label="Escola" required vazio="Escolha" opcoes={escolas.map((s) => ({ valor: s.id, rotulo: s.name }))} />
              <Campo name="name" label="Nome da turma" required maxLength={80} />
              <Campo name="grade_label" label="Ano (opcional)" maxLength={40} />
              <div className="sm:mt-6"><BotaoEnviar aguarde="Criando…">Criar turma</BotaoEnviar></div>
            </FormAcao>
          )}
        </Secao>

        <Secao titulo="Turmas">
          {turmas.length === 0 ? <EstadoVazio titulo="Nenhuma turma cadastrada." /> : (
            <ul className="space-y-5">
              {turmas.map((tm) => {
                const daTurma = vinculos.filter((v) => v.class_id === tm.id);
                const disponiveis = professores.filter((pr) => !daTurma.some((v) => v.user_id === pr.id));
                return (
                  <li key={tm.id} className="rounded-lg border border-cinza-200 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-bold">{tm.name} <span className="font-normal text-cinza-600">· {escolas.find((s) => s.id === tm.school_id)?.name}{tm.grade_label && ` · ${tm.grade_label}`}</span></p>
                      <span className="text-sm">Código dos alunos: <code className="rounded bg-cinza-100 px-2 py-1 font-bold tracking-wider">{tm.join_code}</code></span>
                    </div>
                    <div className="mt-3">
                      <p className="text-sm font-bold">Professores</p>
                      {daTurma.length === 0 ? <p className="text-sm text-cinza-600">Nenhum professor vinculado.</p> : (
                        <ul className="mt-1 flex flex-wrap gap-2">
                          {daTurma.map((v) => (
                            <li key={v.user_id}>
                              <form action={desvincularProfessor} className="inline-flex items-center gap-1 rounded-full bg-azul-50 py-1 pl-3 pr-1 text-sm text-azul-900">
                                <input type="hidden" name="class_id" value={tm.id} /><input type="hidden" name="user_id" value={v.user_id} />
                                {professores.find((pr) => pr.id === v.user_id)?.full_name ?? "Professor"}
                                <button className="flex size-6 items-center justify-center rounded-full hover:bg-azul-100" aria-label={`Remover ${professores.find((pr) => pr.id === v.user_id)?.full_name ?? "professor"} da turma ${tm.name}`}><X aria-hidden className="size-3.5" /></button>
                              </form>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                    {disponiveis.length > 0 && (
                      <FormAcao action={vincularProfessor} className="mt-3 flex max-w-lg flex-col gap-2 sm:flex-row sm:items-end">
                        <input type="hidden" name="class_id" value={tm.id} />
                        <div className="flex-1"><Selecao name="teacher_id" label="Vincular professor" vazio="Escolha o professor" opcoes={disponiveis.map((pr) => ({ valor: pr.id, rotulo: pr.full_name }))} /></div>
                        <BotaoEnviar className="botao botao-secundario" aguarde="Vinculando…">Vincular</BotaoEnviar>
                      </FormAcao>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </Secao>
      </div>
    </>
  );
}
