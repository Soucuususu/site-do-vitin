import { exigirSessao } from "@/lib/auth";
import { AppShell } from "@/components/layout/shell";

export default async function LayoutAdmin({ children }: { children: React.ReactNode }) {
  const { perfil } = await exigirSessao("admin");
  return <AppShell perfil={perfil}>{children}</AppShell>;
}
