import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Clock, ShieldOff } from "lucide-react";
import { getSessao } from "@/lib/auth";
import { rotaInicial } from "@/lib/rotas";
import { sair } from "@/lib/acoes/auth";
import { Logo } from "@/components/layout/logo";

export const metadata: Metadata = { title: "Situação da conta" };

export default async function PaginaPendente() {
  const s = await getSessao();
  if (!s?.perfil) redirect("/entrar");
  if (s.perfil.status === "active") redirect(rotaInicial(s.perfil.role));
  const suspensa = s.perfil.status === "suspended";

  return (
    <div className="flex min-h-screen flex-col items-center px-4 py-8">
      <Logo href="/" />
      <main className="painel mt-8 w-full max-w-md p-8 text-center">
        <span className={`mx-auto flex size-12 items-center justify-center rounded-full ${suspensa ? "bg-vermelho-50 text-vermelho-700" : "bg-ambar-50 text-ambar-700"}`}>
          {suspensa ? <ShieldOff aria-hidden className="size-6" /> : <Clock aria-hidden className="size-6" />}
        </span>
        <h1 className="mt-4 text-2xl">{suspensa ? "Conta suspensa" : "Aguardando aprovação"}</h1>
        <p className="mt-2 text-cinza-600">
          {suspensa
            ? "O acesso desta conta foi suspenso. Procure a administração da sua escola para resolver."
            : "Sua conta de professor foi criada e está aguardando a aprovação da escola. Você poderá entrar no painel assim que ela for liberada."}
        </p>
        <form action={sair} className="mt-6"><button className="botao botao-secundario">Sair da conta</button></form>
      </main>
    </div>
  );
}
