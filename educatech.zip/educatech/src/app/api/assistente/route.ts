import { NextResponse } from "next/server";
import { z } from "zod";
import { getSessao } from "@/lib/auth";
import { configuracaoIA, instrucoesDoSistema, perguntarIA, respostaDemonstrativa } from "@/lib/ia/assistente";

const LIMITE_POR_10_MIN = 15;
const LIMITE_POR_HORA = 60;

const corpo = z.object({
  mensagens: z.array(z.object({
    role: z.enum(["user", "assistant"]),
    content: z.string().trim().min(1).max(2000),
  })).min(1).max(16),
});

const erro = (mensagem: string, status: number) => NextResponse.json({ erro: mensagem }, { status });

export async function POST(req: Request) {
  // 1) Quem está pedindo? Apenas alunos com conta ativa.
  const s = await getSessao();
  if (!s) return erro("Faça login para usar o assistente.", 401);
  if (!s.perfil || s.perfil.status !== "active" || s.perfil.role !== "student") {
    return erro("O assistente está disponível apenas para alunos.", 403);
  }

  // 2) Validação no servidor.
  let json: unknown;
  try { json = await req.json(); } catch { return erro("Pedido inválido.", 400); }
  const v = corpo.safeParse(json);
  if (!v.success || v.data.mensagens.at(-1)?.role !== "user") return erro("Mensagem inválida. Escreva uma pergunta de até 2000 caracteres.", 400);
  const mensagens = v.data.mensagens;

  // 3) Limite de requisições (guardado no banco; não guarda o conteúdo das conversas).
  const agora = Date.now();
  const [dezMin, hora] = await Promise.all([
    s.supabase.from("ai_requests").select("id", { count: "exact", head: true }).eq("user_id", s.user.id).gte("created_at", new Date(agora - 10 * 60_000).toISOString()),
    s.supabase.from("ai_requests").select("id", { count: "exact", head: true }).eq("user_id", s.user.id).gte("created_at", new Date(agora - 60 * 60_000).toISOString()),
  ]);
  if ((dezMin.count ?? 0) >= LIMITE_POR_10_MIN || (hora.count ?? 0) >= LIMITE_POR_HORA) {
    return erro("Você fez muitas perguntas em pouco tempo. Respire, revise o que já aprendeu e tente de novo em alguns minutos.", 429);
  }
  await s.supabase.from("ai_requests").insert({ user_id: s.user.id });

  // 4) Sem chave configurada: modo demonstrativo, claramente identificado.
  const cfg = configuracaoIA();
  if (!cfg) {
    return NextResponse.json({ resposta: respostaDemonstrativa(mensagens.at(-1)!.content), modoDemonstrativo: true });
  }

  // 5) IA real. Só vão para o provedor: as mensagens e o ano escolar. Nada de nome, e-mail ou dados do banco.
  try {
    const resposta = await perguntarIA(cfg, instrucoesDoSistema(s.perfil.grade_label), mensagens);
    return NextResponse.json({ resposta, modoDemonstrativo: false });
  } catch (e) {
    console.error("[assistente] falha ao consultar a IA:", e instanceof Error ? e.message : "desconhecida");
    return erro("O assistente não está disponível agora. Tente novamente em instantes.", 502);
  }
}
