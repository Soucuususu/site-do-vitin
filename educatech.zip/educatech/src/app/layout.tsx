import type { Metadata, Viewport } from "next";
import "@fontsource/atkinson-hyperlegible/400.css";
import "@fontsource/atkinson-hyperlegible/700.css";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "EducaTech — apoio ao aprendizado", template: "%s · EducaTech" },
  description: "Plataforma educacional que aproxima alunos e professores e usa inteligência artificial como apoio ao estudo.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#1f58cc" };

// Aplica as preferências de acessibilidade antes da tela aparecer (evita "piscar").
const SCRIPT_PREFERENCIAS = `try{var f=localStorage.getItem('educatech:fonte');if(f&&['100','112.5','125','150'].indexOf(f)>=0)document.documentElement.style.fontSize=f+'%';if(localStorage.getItem('educatech:contraste')==='alto')document.documentElement.dataset.contraste='alto';}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: SCRIPT_PREFERENCIAS }} /></head>
      <body>{children}</body>
    </html>
  );
}
