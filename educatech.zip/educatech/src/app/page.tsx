import Link from "next/link";
import { BookOpenCheck, ClipboardList, Bell, CalendarDays, LineChart, Lightbulb, ListChecks, ShieldCheck, Accessibility, Sparkles, MessageCircleQuestion } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Rodape } from "@/components/layout/rodape";
import { Acessibilidade } from "@/components/layout/acessibilidade";

const RECURSOS = [
  { icone: ClipboardList, titulo: "Atividades organizadas", texto: "Professores publicam tarefas com matéria, instruções e prazo. Alunos entregam e acompanham a situação de cada uma." },
  { icone: BookOpenCheck, titulo: "Devolutivas que ajudam", texto: "Comentários do professor chegam junto da atividade, com indicação do que vale a pena revisar." },
  { icone: Bell, titulo: "Avisos e notificações", texto: "Novas atividades, mudanças de prazo e recados da turma aparecem em um só lugar." },
  { icone: CalendarDays, titulo: "Calendário simples", texto: "Todos os prazos do mês em uma tela, no computador ou no celular." },
  { icone: LineChart, titulo: "Acompanhamento da turma", texto: "O professor vê participação, entregas em aberto e os conteúdos mais indicados para revisão, para planejar as aulas." },
];

export default function PaginaInicial() {
  return (
    <>
      <a href="#conteudo" className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:font-bold">Ir para o conteúdo</a>
      <header className="border-b border-cinza-200 bg-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <Logo />
          <nav aria-label="Principal" className="flex items-center gap-2">
            <a href="#recursos" className="botao botao-leve hidden md:inline-flex">Recursos</a>
            <a href="#ia" className="botao botao-leve hidden md:inline-flex">Inteligência artificial</a>
            <a href="#seguranca" className="botao botao-leve hidden md:inline-flex">Segurança</a>
            <Link href="/entrar" className="botao botao-secundario">Entrar</Link>
            <Link href="/criar-conta" className="botao botao-primario">Criar conta</Link>
          </nav>
        </div>
      </header>

      <main id="conteudo">
        <section className="bg-white">
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.1fr_1fr] lg:py-20">
            <div>
              <p className="mb-3 inline-block rounded-full bg-azul-50 px-3 py-1 text-sm font-bold text-azul-800">Plataforma educacional</p>
              <h1 className="text-4xl sm:text-5xl">Atividades em ordem, dúvidas respondidas e professores por perto.</h1>
              <p className="mt-5 max-w-xl text-lg text-cinza-600">
                O EducaTech reúne as tarefas da escola, os avisos da turma e um assistente de estudo com inteligência artificial que ensina a pensar, em vez de entregar respostas prontas.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/criar-conta" className="botao botao-primario px-6">Criar conta</Link>
                <Link href="/entrar" className="botao botao-secundario px-6">Entrar</Link>
              </div>
              <p className="mt-5 max-w-xl text-sm text-cinza-600">
                O EducaTech é uma ferramenta de apoio à educação. Ele não substitui os professores: aproxima alunos e professores por meio da tecnologia.
              </p>
            </div>

            <figure aria-label="Exemplo de conversa com o Assistente EducaTech" className="painel overflow-hidden shadow-sm">
              <figcaption className="flex items-center gap-2 border-b border-cinza-200 bg-cinza-50 px-4 py-2.5 text-sm font-bold text-cinza-700">
                <Sparkles aria-hidden className="size-4 text-azul-600" /> Exemplo de conversa com o Assistente
              </figcaption>
              <div className="space-y-4 p-5 text-[0.95rem]">
                <p className="ml-auto max-w-[85%] rounded-xl bg-azul-600 px-4 py-2.5 text-white"><span className="sr-only">Aluno: </span>Não entendi como resolver 2x + 6 = 14.</p>
                <p className="max-w-[90%] rounded-xl bg-cinza-100 px-4 py-2.5"><span className="sr-only">Assistente: </span>Vamos por partes. O objetivo é deixar o x sozinho. O que você poderia fazer com o 6 nos dois lados da igualdade? Tente o primeiro passo e me conte o que achou.</p>
                <p className="ml-auto max-w-[85%] rounded-xl bg-azul-600 px-4 py-2.5 text-white"><span className="sr-only">Aluno: </span>Tirar 6 dos dois lados? Ficou 2x = 8.</p>
                <p className="max-w-[90%] rounded-xl bg-cinza-100 px-4 py-2.5"><span className="sr-only">Assistente: </span>Isso! E agora, como descobrir quanto vale um x só?</p>
              </div>
              <p className="border-t border-cinza-200 px-5 py-2 text-xs text-cinza-600">Ilustração do estilo de conversa. Não é uma conversa real.</p>
            </figure>
          </div>
        </section>

        <section id="recursos" className="mx-auto max-w-6xl scroll-mt-4 px-4 py-16 sm:px-6">
          <h2 className="text-3xl">O que você encontra na plataforma</h2>
          <p className="mt-2 max-w-2xl text-cinza-600">Cada pessoa tem o seu painel: alunos, professores e administradores veem apenas o que precisam.</p>
          <ul className="mt-8 divide-y divide-cinza-200 rounded-xl border border-cinza-200 bg-white">
            {RECURSOS.map(({ icone: Icone, titulo, texto }) => (
              <li key={titulo} className="flex gap-4 p-5">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-azul-50 text-azul-700"><Icone aria-hidden className="size-5" /></span>
                <div><h3 className="text-lg">{titulo}</h3><p className="text-cinza-600">{texto}</p></div>
              </li>
            ))}
          </ul>
        </section>

        <section id="ia" className="scroll-mt-4 bg-azul-900 text-white">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
            <h2 className="text-3xl !text-white">Como a inteligência artificial ajuda no aprendizado</h2>
            <p className="mt-2 max-w-2xl text-azul-100">O Assistente EducaTech funciona como um tutor: explica, pergunta, propõe exercícios e admite quando não sabe.</p>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {[
                { i: MessageCircleQuestion, t: "Pergunta antes de responder", d: "Incentiva o aluno a tentar o primeiro passo. Só depois mostra a resolução passo a passo." },
                { i: Lightbulb, t: "Explica de outro jeito", d: "Se a explicação não funcionou, tenta outro exemplo, com linguagem adequada ao ano escolar." },
                { i: ListChecks, t: "Cria prática e resumos", d: "Gera exercícios e resumos para revisar o conteúdo, sem substituir a orientação do professor." },
              ].map(({ i: Icone, t, d }) => (
                <div key={t} className="rounded-xl border border-white/15 bg-white/5 p-5">
                  <Icone aria-hidden className="size-6 text-azul-200" />
                  <h3 className="mt-3 text-lg !text-white">{t}</h3>
                  <p className="mt-1 text-azul-100">{d}</p>
                </div>
              ))}
            </div>
            <p className="mt-6 max-w-3xl text-sm text-azul-100">A IA nunca acessa o banco de dados da escola: ela recebe apenas a pergunta do aluno e o ano escolar. A chave do serviço de IA fica guardada no servidor, nunca no navegador.</p>
          </div>
        </section>

        <section id="seguranca" className="mx-auto grid max-w-6xl scroll-mt-4 gap-10 px-4 py-16 sm:px-6 md:grid-cols-2">
          <div>
            <h2 className="flex items-center gap-2 text-2xl"><ShieldCheck aria-hidden className="size-6 text-azul-600" />Segurança e privacidade</h2>
            <ul className="mt-4 list-disc space-y-2 pl-5 text-cinza-700">
              <li>Cada aluno vê apenas as suas informações e as atividades das suas turmas.</li>
              <li>Contas de professor só são liberadas após aprovação da escola.</li>
              <li>As regras de acesso são aplicadas no banco de dados, não apenas escondidas na tela.</li>
              <li>Senhas são tratadas pelo serviço de autenticação e nunca ficam em texto puro.</li>
              <li>Sem rankings públicos nem notas expostas para a turma.</li>
              <li>Coletamos o mínimo de dados pessoais necessário.</li>
            </ul>
          </div>
          <div>
            <h2 className="flex items-center gap-2 text-2xl"><Accessibility aria-hidden className="size-6 text-azul-600" />Acessibilidade</h2>
            <ul className="mt-4 list-disc space-y-2 pl-5 text-cinza-700">
              <li>Ajuste do tamanho do texto e modo de alto contraste.</li>
              <li>Navegação completa pelo teclado e compatibilidade com leitores de tela.</li>
              <li>Formulários com rótulos e mensagens de erro claras.</li>
              <li>Layout que se adapta a computadores, tablets e celulares.</li>
              <li>Fonte escolhida para facilitar a leitura.</li>
            </ul>
            <div className="mt-5"><p className="mb-2 text-sm font-bold">Experimente agora:</p><Acessibilidade /></div>
          </div>
        </section>
      </main>
      <Rodape />
    </>
  );
}
