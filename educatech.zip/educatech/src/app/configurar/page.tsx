import { Logo } from "@/components/layout/logo";

export default function Configurar() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <Logo />
      <main className="painel mt-8 p-6">
        <h1 className="text-2xl">Falta configurar o Supabase</h1>
        <p className="mt-2">O projeto está funcionando, mas ainda não encontrou as chaves do banco de dados.</p>
        <ol className="mt-4 list-decimal space-y-2 pl-5">
          <li>Copie o arquivo <code className="rounded bg-cinza-100 px-1">.env.example</code> para <code className="rounded bg-cinza-100 px-1">.env.local</code>.</li>
          <li>Preencha <code className="rounded bg-cinza-100 px-1">NEXT_PUBLIC_SUPABASE_URL</code> e <code className="rounded bg-cinza-100 px-1">NEXT_PUBLIC_SUPABASE_ANON_KEY</code> (Supabase → Project Settings → API).</li>
          <li>Pare o servidor (Ctrl + C) e rode <code className="rounded bg-cinza-100 px-1">npm run dev</code> de novo.</li>
        </ol>
        <p className="mt-4 text-sm text-cinza-600">Veja o passo a passo completo no README.md.</p>
      </main>
    </div>
  );
}
