import type { Metadata } from "next";
import Link from "next/link";
import { FormAcao, Campo, BotaoEnviar } from "@/components/form";
import { recuperarSenha } from "@/lib/acoes/auth";

export const metadata: Metadata = { title: "Recuperar senha" };

export default function PaginaRecuperarSenha() {
  return (
    <>
      <h1 className="text-2xl">Recuperar senha</h1>
      <p className="mt-1 text-cinza-600">Informe o e-mail da conta. Enviaremos um link para criar uma nova senha.</p>
      <div className="mt-5">
        <FormAcao action={recuperarSenha}>
          <Campo name="email" label="E-mail" type="email" autoComplete="email" inputMode="email" required />
          <BotaoEnviar className="botao botao-primario w-full" aguarde="Enviando…">Enviar link</BotaoEnviar>
        </FormAcao>
      </div>
      <p className="mt-5 text-sm"><Link href="/entrar" className="link">Voltar para entrar</Link></p>
    </>
  );
}
