import { Logo } from "@/components/layout/logo";
import { Acessibilidade } from "@/components/layout/acessibilidade";

export default function LayoutAuth({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col items-center px-4 py-8">
      <a href="#conteudo" className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:font-bold">Ir para o conteúdo</a>
      <Logo />
      <main id="conteudo" className="painel mt-8 w-full max-w-md p-6 sm:p-8">{children}</main>
      <div className="mt-6"><Acessibilidade /></div>
    </div>
  );
}
