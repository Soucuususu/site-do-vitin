import type { Metadata } from "next";
import Link from "next/link";
import { FormAcao, Campo, CampoSenha, BotaoEnviar } from "@/components/form";
import { Aviso } from "@/components/ui";
import { entrar } from "@/lib/acoes/auth";

export const metadata: Metadata = { title: "Entrar" };

export default async function PaginaEntrar({ searchParams }: { searchParams: Promise<{ cadastro?: string; confirmado?: string; erro?: string }> }) {
  const p = await searchParams;
  return (
    <>
      <h1 className="text-2xl">Entrar</h1>
      <p className="mt-1 text-cinza-600">Use o e-mail e a senha da sua conta.</p>
      <div className="mt-4 space-y-3">
        {p.cadastro === "ok" && <Aviso tom="ok" titulo="Conta criada!">Enviamos um e-mail de confirmação. Abra a mensagem, confirme o endereço e depois entre.</Aviso>}
        {p.erro === "link" && <Aviso tom="erro" titulo="Link inválido ou expirado.">Peça um novo link ou tente entrar normalmente.</Aviso>}
      </div>
      <div className="mt-5">
        <FormAcao action={entrar}>
          <Campo name="email" label="E-mail" type="email" autoComplete="email" required inputMode="email" />
          <CampoSenha name="password" label="Senha" autoComplete="current-password" required />
          <BotaoEnviar className="botao botao-primario w-full" aguarde="Entrando…">Entrar</BotaoEnviar>
        </FormAcao>
      </div>
      <p className="mt-5 text-sm"><Link href="/recuperar-senha" className="link">Esqueci minha senha</Link></p>
      <p className="mt-2 text-sm">Ainda não tem conta? <Link href="/criar-conta" className="link">Criar conta</Link></p>
    </>
  );
}
