import type { Metadata } from "next";
import { FormAcao, CampoSenha, BotaoEnviar } from "@/components/form";
import { redefinirSenha } from "@/lib/acoes/auth";

export const metadata: Metadata = { title: "Nova senha" };

export default function PaginaRedefinirSenha() {
  return (
    <>
      <h1 className="text-2xl">Criar nova senha</h1>
      <p className="mt-1 text-cinza-600">Escolha uma senha nova para a sua conta.</p>
      <div className="mt-5">
        <FormAcao action={redefinirSenha}>
          <CampoSenha name="password" label="Nova senha" autoComplete="new-password" required ajuda="Mínimo de 8 caracteres, com letras e números." />
          <CampoSenha name="confirm" label="Confirmar nova senha" autoComplete="new-password" required />
          <BotaoEnviar className="botao botao-primario w-full" aguarde="Salvando…">Salvar nova senha</BotaoEnviar>
        </FormAcao>
      </div>
    </>
  );
}
