import type { Metadata } from "next";
import Link from "next/link";
import { FormAcao, Campo, CampoSenha, Selecao, BotaoEnviar } from "@/components/form";
import { Aviso } from "@/components/ui";
import { cadastrar } from "@/lib/acoes/auth";

export const metadata: Metadata = { title: "Criar conta" };

export default function PaginaCriarConta() {
  return (
    <>
      <h1 className="text-2xl">Criar conta</h1>
      <p className="mt-1 text-cinza-600">Preencha os dados abaixo. Campos com * são obrigatórios.</p>
      <div className="mt-5">
        <FormAcao action={cadastrar}>
          <Campo name="full_name" label="Nome completo" autoComplete="name" required />
          <Campo name="email" label="E-mail" type="email" autoComplete="email" inputMode="email" required />
          <Selecao name="account_type" label="Tipo de conta" required defaultValue="student"
            opcoes={[{ valor: "student", rotulo: "Aluno" }, { valor: "teacher", rotulo: "Professor" }]} />
          <Campo name="code" label="Código da turma (aluno) ou da escola (professor)" maxLength={20}
            ajuda="Opcional. Quem deve fornecer o código é a sua escola. Alunos também podem informar a turma depois de entrar." />
          <CampoSenha name="password" label="Senha" autoComplete="new-password" required ajuda="Mínimo de 8 caracteres, com letras e números." />
          <CampoSenha name="confirm" label="Confirmar senha" autoComplete="new-password" required />
          <Aviso tom="info" titulo="Conta de professor">
            Contas de professor ficam aguardando a aprovação da escola antes de liberar o painel.
          </Aviso>
          <BotaoEnviar className="botao botao-primario w-full" aguarde="Criando conta…">Criar conta</BotaoEnviar>
        </FormAcao>
      </div>
      <p className="mt-5 text-sm">Já tem conta? <Link href="/entrar" className="link">Entrar</Link></p>
    </>
  );
}
