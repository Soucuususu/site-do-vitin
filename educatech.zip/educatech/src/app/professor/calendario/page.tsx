import type { Metadata } from "next";
import { exigirSessao } from "@/lib/auth";
import { Calendario, mesDaUrl } from "@/components/calendario";
import { TituloPagina } from "@/components/ui";
import type { Atividade } from "@/lib/tipos";

export const metadata: Metadata = { title: "Calendário" };

export default async function CalendarioProfessor({ searchParams }: { searchParams: Promise<{ mes?: string }> }) {
  const { supabase, user } = await exigirSessao("teacher");
  const { mes } = await searchParams;
  const { ano, mes: m } = mesDaUrl(mes);
  const { data } = await supabase.from("activities").select("*").eq("teacher_id", user.id).order("due_at");
  const atividades = (data ?? []) as Atividade[];
  return (
    <>
      <TituloPagina titulo="Calendário" descricao="Prazos das atividades que você publicou." />
      <Calendario ano={ano} mes={m} base="/professor/calendario"
        itens={atividades.map((a) => ({ id: a.id, titulo: a.title, materia: a.subject, prazo: a.due_at, href: `/professor/atividades/${a.id}` }))} />
    </>
  );
}
