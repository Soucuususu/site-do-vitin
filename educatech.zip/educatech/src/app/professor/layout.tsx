import { exigirSessao } from "@/lib/auth";
import { AppShell } from "@/components/layout/shell";

export default async function LayoutProfessor({ children }: { children: React.ReactNode }) {
  const { perfil } = await exigirSessao("teacher");
  return <AppShell perfil={perfil}>{children}</AppShell>;
}
