import type { Metadata } from "next";
import { exigirSessao } from "@/lib/auth";
import { carregarProfessor, indicadoresDaTurma } from "@/lib/consultas";
import { Aviso, EstadoVazio, Progresso, TituloPagina } from "@/components/ui";

export const metadata: Metadata = { title: "Turmas" };

export default async function Turmas() {
  const { supabase, user } = await exigirSessao("teacher");
  const d = await carregarProfessor(supabase, user.id);

  return (
    <>
      <TituloPagina titulo="Turmas" descricao="Acompanhe a participação e planeje as próximas aulas." />
      <div className="mb-6">
        <Aviso tom="info" titulo="Como ler estes indicadores">
          Eles ajudam no planejamento pedagógico. Não são diagnósticos e não devem ser usados para rotular alunos. Esta página só é visível para você, professor(a) da turma.
        </Aviso>
      </div>
      {d.turmas.length === 0 ? <EstadoVazio titulo="Você ainda não está vinculado a nenhuma turma." /> : (
        <div className="space-y-6">
          {d.turmas.map((t) => {
            const i = indicadoresDaTurma(d, t.id);
            return (
              <section key={t.id} className="painel" aria-labelledby={`t-${t.id}`}>
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cinza-200 px-5 py-3">
                  <h2 id={`t-${t.id}`} className="text-xl">{t.name}{t.grade_label && <span className="text-base font-normal text-cinza-600"> · {t.grade_label}</span>}</h2>
                  <p className="text-sm">Código para alunos: <code className="rounded bg-cinza-100 px-2 py-1 font-bold tracking-wider">{t.join_code}</code></p>
                </div>
                <div className="grid gap-6 p-5 lg:grid-cols-2">
                  <div className="space-y-4">
                    <Progresso valor={i.percentualConcluido} rotulo="Atividades entregues" />
                    <Progresso valor={i.participacao} rotulo="Alunos que já entregaram algo" />
                    <div>
                      <h3 className="text-base">Conteúdos mais indicados para revisão</h3>
                      {i.topicos.length === 0 ? (
                        <p className="mt-1 text-sm text-cinza-600">Nenhum ainda. Ao corrigir, preencha “Sugestão de revisão” para alimentar este painel.</p>
                      ) : (
                        <ol className="mt-1 list-decimal pl-5 text-sm">{i.topicos.map(([nome, qtd]) => <li key={nome}>{nome} <span className="text-cinza-600">({qtd} {qtd === 1 ? "indicação" : "indicações"})</span></li>)}</ol>
                      )}
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-base">Entregas em aberto (prazo vencido)</h3>
                      {i.emAberto.length === 0 ? <p className="mt-1 text-sm text-cinza-600">Nenhum aluno com entregas em aberto.</p> : (
                        <ul className="mt-1 text-sm">{i.emAberto.map((x) => <li key={x.aluno.id}>{x.aluno.full_name}: {x.quantidade} {x.quantidade === 1 ? "atividade" : "atividades"}</li>)}</ul>
                      )}
                    </div>
                    <details>
                      <summary className="cursor-pointer text-base font-bold text-azul-800">Alunos da turma ({i.alunos.length})</summary>
                      {i.alunos.length === 0 ? <p className="mt-1 text-sm text-cinza-600">Nenhum aluno ainda. Compartilhe o código da turma.</p> : (
                        <ul className="mt-2 columns-1 text-sm sm:columns-2">{i.alunos.map((a) => <li key={a.id}>{a.full_name}</li>)}</ul>
                      )}
                    </details>
                  </div>
                </div>
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}
