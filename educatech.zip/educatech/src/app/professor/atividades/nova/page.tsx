import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { criarAtividade } from "@/lib/acoes/professor";
import { FormAcao, BotaoEnviar } from "@/components/form";
import { CamposAtividade } from "@/components/campos-atividade";
import { EstadoVazio, TituloPagina } from "@/components/ui";
import type { Turma } from "@/lib/tipos";

export const metadata: Metadata = { title: "Nova atividade" };

export default async function NovaAtividade() {
  const { supabase } = await exigirSessao("teacher");
  const { data } = await supabase.from("classes").select("id,name").order("name");
  const turmas = (data ?? []) as Pick<Turma, "id" | "name">[];

  return (
    <>
      <Link href="/professor/atividades" className="link mb-4 inline-flex items-center gap-1 text-sm"><ArrowLeft aria-hidden className="size-4" />Voltar</Link>
      <TituloPagina titulo="Nova atividade" descricao="Os alunos da turma serão notificados quando você publicar." />
      {turmas.length === 0 ? (
        <EstadoVazio titulo="Você ainda não está vinculado a nenhuma turma.">Peça à administração da escola para vincular você às turmas.</EstadoVazio>
      ) : (
        <div className="painel painel-corpo max-w-2xl">
          <FormAcao action={criarAtividade}>
            <CamposAtividade turmas={turmas} />
            <p className="ajuda">Anexos de arquivos ainda não estão disponíveis nesta versão. Se precisar de material, cole o link nas instruções.</p>
            <BotaoEnviar aguarde="Publicando…">Publicar atividade</BotaoEnviar>
          </FormAcao>
        </div>
      )}
    </>
  );
}
