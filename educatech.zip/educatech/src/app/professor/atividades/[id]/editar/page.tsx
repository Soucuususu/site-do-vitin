import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { editarAtividade } from "@/lib/acoes/professor";
import { uuid } from "@/lib/validacao";
import { FormAcao, BotaoEnviar } from "@/components/form";
import { CamposAtividade } from "@/components/campos-atividade";
import { TituloPagina } from "@/components/ui";
import type { Atividade } from "@/lib/tipos";

export const metadata: Metadata = { title: "Editar atividade" };

export default async function EditarAtividade({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!uuid.safeParse(id).success) notFound();
  const { supabase, user } = await exigirSessao("teacher");
  const { data } = await supabase.from("activities").select("*").eq("id", id).maybeSingle();
  const atividade = data as Atividade | null;
  if (!atividade || atividade.teacher_id !== user.id) notFound();

  return (
    <>
      <Link href={`/professor/atividades/${id}`} className="link mb-4 inline-flex items-center gap-1 text-sm"><ArrowLeft aria-hidden className="size-4" />Voltar</Link>
      <TituloPagina titulo="Editar atividade" descricao="Se você mudar o prazo, os alunos serão avisados." />
      <div className="painel painel-corpo max-w-2xl">
        <FormAcao action={editarAtividade}>
          <input type="hidden" name="id" value={id} />
          <CamposAtividade atividade={atividade} />
          <BotaoEnviar aguarde="Salvando…">Salvar alterações</BotaoEnviar>
        </FormAcao>
      </div>
    </>
  );
}
