import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Pencil } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { corrigirEntrega, excluirAtividade } from "@/lib/acoes/professor";
import { dataHora } from "@/lib/formato";
import { uuid } from "@/lib/validacao";
import { Aviso, Etiqueta, EstadoVazio, Secao } from "@/components/ui";
import { FormAcao, AreaTexto, Campo, BotaoEnviar } from "@/components/form";
import type { Atividade, Devolutiva, Entrega, Turma } from "@/lib/tipos";

export const metadata: Metadata = { title: "Atividade" };

export default async function DetalheAtividadeProfessor({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ publicada?: string; salva?: string }> }) {
  const { id } = await params;
  const q = await searchParams;
  if (!uuid.safeParse(id).success) notFound();
  const { supabase, user } = await exigirSessao("teacher");

  const { data } = await supabase.from("activities").select("*").eq("id", id).maybeSingle();
  const atividade = data as Atividade | null;
  if (!atividade || atividade.teacher_id !== user.id) notFound(); // só o autor gerencia

  const [{ data: t }, { data: m }, { data: s }] = await Promise.all([
    supabase.from("classes").select("*").eq("id", atividade.class_id).maybeSingle(),
    supabase.from("class_members").select("user_id").eq("class_id", atividade.class_id).eq("member_role", "student"),
    supabase.from("submissions").select("*").eq("activity_id", id),
  ]);
  const turma = t as Turma | null;
  const entregas = (s ?? []) as Entrega[];
  const idsAlunos = (m ?? []).map((x) => x.user_id as string);
  const { data: p } = idsAlunos.length ? await supabase.from("profiles").select("id,full_name").in("id", idsAlunos) : { data: [] };
  const nomes = new Map((p ?? []).map((x) => [x.id as string, x.full_name as string]));
  const { data: f } = entregas.length ? await supabase.from("feedback").select("*").in("submission_id", entregas.map((e) => e.id)) : { data: [] };
  const devolutivas = new Map(((f ?? []) as Devolutiva[]).map((x) => [x.submission_id, x]));

  const entregues = entregas.map((e) => ({ e, nome: nomes.get(e.student_id) ?? "Aluno" })).sort((x, y) => (x.e.status === y.e.status ? x.nome.localeCompare(y.nome, "pt-BR") : x.e.status === "submitted" ? -1 : 1));
  const quemEntregou = new Set(entregas.map((e) => e.student_id));
  const faltam = idsAlunos.filter((i) => !quemEntregou.has(i)).map((i) => nomes.get(i) ?? "Aluno").sort((a, b) => a.localeCompare(b, "pt-BR"));

  return (
    <>
      <Link href="/professor/atividades" className="link mb-4 inline-flex items-center gap-1 text-sm"><ArrowLeft aria-hidden className="size-4" />Voltar para atividades</Link>
      {q.publicada && <div className="mb-4"><Aviso tom="ok" titulo="Atividade publicada." >Os alunos da turma foram notificados.</Aviso></div>}
      {q.salva && <div className="mb-4"><Aviso tom="ok" titulo="Alterações salvas." /></div>}

      <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs font-bold uppercase tracking-wide text-azul-700">{atividade.subject} · {turma?.name}</p>
          <h1 className="text-2xl sm:text-3xl">{atividade.title}</h1>
          <p className="mt-1 text-sm text-cinza-600">Prazo: {dataHora(atividade.due_at)} · {atividade.kind === "task" ? "Marcar como concluída" : "Resposta escrita"}</p>
        </div>
        <Link href={`/professor/atividades/${id}/editar`} className="botao botao-secundario"><Pencil aria-hidden className="size-4" />Editar</Link>
      </div>

      <div className="space-y-6">
        <Secao titulo="Instruções"><p className="whitespace-pre-wrap">{atividade.instructions}</p></Secao>

        <Secao titulo={`Entregas (${entregas.length}/${idsAlunos.length})`}>
          {entregues.length === 0 ? <EstadoVazio titulo="Nenhuma entrega ainda." /> : (
            <ul className="space-y-6">
              {entregues.map(({ e, nome }) => {
                const dv = devolutivas.get(e.id);
                return (
                  <li key={e.id} className="rounded-lg border border-cinza-200 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-bold">{nome}</p>
                      <div className="flex flex-wrap items-center gap-2 text-sm text-cinza-600">
                        {new Date(e.submitted_at) > new Date(atividade.due_at) && <Etiqueta tom="alerta">Com atraso</Etiqueta>}
                        <Etiqueta tom={e.status === "graded" ? "ok" : "info"}>{e.status === "graded" ? "Corrigida" : "A corrigir"}</Etiqueta>
                        <span>{dataHora(e.submitted_at)}</span>
                      </div>
                    </div>
                    {e.answer_text ? <p className="mt-3 whitespace-pre-wrap rounded-lg bg-cinza-50 p-3 text-sm">{e.answer_text}</p> : <p className="mt-3 text-sm text-cinza-600">Marcou como concluída, sem texto.</p>}
                    <div className="mt-4">
                      <FormAcao action={corrigirEntrega} className="space-y-3">
                        <input type="hidden" name="submission_id" value={e.id} />
                        <AreaTexto name="comment" label="Comentário e orientações" rows={3} required maxLength={3000} defaultValue={dv?.comment} />
                        <Campo name="review_topic" label="Sugestão de revisão (opcional)" maxLength={100} defaultValue={dv?.review_topic ?? ""} ajuda="Ex.: “Equações do 1º grau”. Aparece para o aluno e alimenta o painel da turma." />
                        <BotaoEnviar aguarde="Salvando…">{e.status === "graded" ? "Atualizar devolutiva" : "Salvar e marcar como corrigida"}</BotaoEnviar>
                      </FormAcao>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
          {faltam.length > 0 && (
            <div className="mt-6 border-t border-cinza-200 pt-4">
              <h3 className="text-base">Ainda não entregaram ({faltam.length})</h3>
              <p className="mt-1 text-sm text-cinza-700">{faltam.join(", ")}</p>
            </div>
          )}
        </Secao>

        <details className="painel painel-corpo">
          <summary className="cursor-pointer font-bold text-vermelho-700">Excluir atividade</summary>
          <p className="mt-3 text-sm">Ao excluir, as entregas e devolutivas desta atividade também serão apagadas. Esta ação não pode ser desfeita.</p>
          <form action={excluirAtividade} className="mt-3">
            <input type="hidden" name="id" value={id} />
            <BotaoEnviar className="botao botao-perigo" aguarde="Excluindo…">Sim, excluir esta atividade</BotaoEnviar>
          </form>
        </details>
      </div>
    </>
  );
}
