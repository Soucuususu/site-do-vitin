import type { Metadata } from "next";
import Link from "next/link";
import { Plus } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { carregarProfessor } from "@/lib/consultas";
import { dataHora } from "@/lib/formato";
import { Aviso, Etiqueta, EstadoVazio, TituloPagina } from "@/components/ui";

export const metadata: Metadata = { title: "Atividades" };

export default async function AtividadesProfessor({ searchParams }: { searchParams: Promise<{ excluida?: string }> }) {
  const { supabase, user } = await exigirSessao("teacher");
  const { excluida } = await searchParams;
  const d = await carregarProfessor(supabase, user.id);
  const atividades = [...d.atividades].reverse();

  return (
    <>
      <TituloPagina titulo="Atividades" descricao="Atividades que você publicou." acoes={<Link href="/professor/atividades/nova" className="botao botao-primario"><Plus aria-hidden className="size-4" />Nova atividade</Link>} />
      {excluida && <div className="mb-4"><Aviso tom="ok" titulo="Atividade excluída." /></div>}
      {atividades.length === 0 ? (
        <EstadoVazio titulo="Você ainda não publicou atividades.">Clique em “Nova atividade” para começar.</EstadoVazio>
      ) : (
        <ul className="space-y-3">
          {atividades.map((a) => {
            const alunos = d.alunosPorTurma.get(a.class_id)?.length ?? 0;
            const ents = d.entregas.filter((e) => e.activity_id === a.id);
            const aCorrigir = ents.filter((e) => e.status === "submitted").length;
            return (
              <li key={a.id}>
                <Link href={`/professor/atividades/${a.id}`} className="painel flex flex-wrap items-center justify-between gap-3 p-4 hover:border-azul-500">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wide text-azul-700">{a.subject} · {d.turmas.find((t) => t.id === a.class_id)?.name}</p>
                    <p className="text-lg font-bold text-cinza-900">{a.title}</p>
                    <p className="text-sm text-cinza-600">Prazo: {dataHora(a.due_at)}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Etiqueta tom="neutro">{ents.length}/{alunos} entregas</Etiqueta>
                    {aCorrigir > 0 && <Etiqueta tom="info">{aCorrigir} a corrigir</Etiqueta>}
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
