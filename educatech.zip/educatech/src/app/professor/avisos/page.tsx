import type { Metadata } from "next";
import { Trash2 } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { criarAviso, excluirAviso } from "@/lib/acoes/professor";
import { dataHora } from "@/lib/formato";
import { FormAcao, Campo, AreaTexto, Selecao, BotaoEnviar } from "@/components/form";
import { EstadoVazio, Secao, TituloPagina } from "@/components/ui";
import type { Aviso, Turma } from "@/lib/tipos";

export const metadata: Metadata = { title: "Avisos" };

export default async function AvisosProfessor() {
  const { supabase, user } = await exigirSessao("teacher");
  const [{ data: t }, { data: a }] = await Promise.all([
    supabase.from("classes").select("id,name").order("name"),
    supabase.from("announcements").select("*").eq("teacher_id", user.id).order("created_at", { ascending: false }).limit(30),
  ]);
  const turmas = (t ?? []) as Pick<Turma, "id" | "name">[];
  const avisos = (a ?? []) as Aviso[];

  return (
    <>
      <TituloPagina titulo="Avisos" descricao="Recados para os alunos das suas turmas. Eles recebem uma notificação." />
      <div className="space-y-6">
        <Secao titulo="Novo aviso">
          {turmas.length === 0 ? <EstadoVazio titulo="Você ainda não está vinculado a nenhuma turma." /> : (
            <FormAcao action={criarAviso} className="max-w-2xl space-y-5">
              <Selecao name="class_id" label="Turma" required vazio="Escolha a turma" opcoes={turmas.map((x) => ({ valor: x.id, rotulo: x.name }))} />
              <Campo name="title" label="Título" required maxLength={140} />
              <AreaTexto name="body" label="Mensagem" required rows={4} maxLength={2000} />
              <BotaoEnviar aguarde="Publicando…">Publicar aviso</BotaoEnviar>
            </FormAcao>
          )}
        </Secao>
        <Secao titulo="Avisos publicados">
          {avisos.length === 0 ? <EstadoVazio titulo="Você ainda não publicou avisos." /> : (
            <ul className="divide-y divide-cinza-200">
              {avisos.map((v) => (
                <li key={v.id} className="flex flex-wrap items-start justify-between gap-3 py-3 first:pt-0 last:pb-0">
                  <div>
                    <p className="font-bold">{v.title}</p>
                    <p className="whitespace-pre-wrap text-sm">{v.body}</p>
                    <p className="mt-1 text-xs text-cinza-600">{turmas.find((x) => x.id === v.class_id)?.name} · {dataHora(v.created_at)}</p>
                  </div>
                  <form action={excluirAviso}><input type="hidden" name="id" value={v.id} /><button className="botao botao-perigo botao-pequeno" aria-label={`Excluir aviso: ${v.title}`}><Trash2 aria-hidden className="size-4" />Excluir</button></form>
                </li>
              ))}
            </ul>
          )}
        </Secao>
      </div>
    </>
  );
}
