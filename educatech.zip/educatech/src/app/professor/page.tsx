import type { Metadata } from "next";
import Link from "next/link";
import { Plus } from "lucide-react";
import { exigirSessao } from "@/lib/auth";
import { carregarProfessor, indicadoresDaTurma } from "@/lib/consultas";
import { dataHora, prazoRelativo, primeiroNome } from "@/lib/formato";
import { Aviso, EstadoVazio, Numero, Progresso, Secao } from "@/components/ui";

export const metadata: Metadata = { title: "Início" };

export default async function InicioProfessor() {
  const { supabase, user, perfil } = await exigirSessao("teacher");
  const d = await carregarProfessor(supabase, user.id);
  const aCorrigir = d.entregas.filter((e) => e.status === "submitted");
  const proximos = d.atividades.filter((a) => new Date(a.due_at) >= new Date()).slice(0, 5);
  const totalAlunos = new Set([...d.alunosPorTurma.values()].flat().map((a) => a.id)).size;
  const porAtividade = new Map<string, number>();
  for (const e of aCorrigir) porAtividade.set(e.activity_id, (porAtividade.get(e.activity_id) ?? 0) + 1);

  return (
    <>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl">Olá, {primeiroNome(perfil.full_name)}!</h1>
          <p className="mt-1 text-cinza-600">Resumo das suas turmas e atividades.</p>
        </div>
        <Link href="/professor/atividades/nova" className="botao botao-primario"><Plus aria-hidden className="size-4" />Nova atividade</Link>
      </div>

      {d.erro && <div className="mb-4"><Aviso tom="erro" titulo="Não foi possível carregar tudo.">Atualize a página em instantes.</Aviso></div>}

      {d.turmas.length === 0 ? (
        <EstadoVazio titulo="Você ainda não está vinculado a nenhuma turma.">A administração da escola precisa vincular você às turmas. Depois disso, você poderá publicar atividades.</EstadoVazio>
      ) : (
        <>
          <section aria-label="Resumo" className="painel painel-corpo grid grid-cols-2 gap-6 sm:grid-cols-4">
            <Numero valor={d.turmas.length} rotulo="turmas" />
            <Numero valor={totalAlunos} rotulo="alunos" />
            <Numero valor={d.atividades.length} rotulo="atividades publicadas" />
            <Numero valor={aCorrigir.length} rotulo="a corrigir" />
          </section>

          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <Secao titulo="Pendentes de correção">
              {porAtividade.size === 0 ? <EstadoVazio titulo="Nenhuma correção pendente." /> : (
                <ul className="divide-y divide-cinza-200">
                  {[...porAtividade.entries()].map(([id, qtd]) => {
                    const a = d.atividades.find((x) => x.id === id);
                    return a && (
                      <li key={id} className="flex items-center justify-between gap-3 py-3 first:pt-0 last:pb-0">
                        <div><Link href={`/professor/atividades/${id}`} className="font-bold text-azul-800 hover:underline">{a.title}</Link><p className="text-sm text-cinza-600">{a.subject}</p></div>
                        <span className="rounded-full bg-azul-50 px-2.5 py-0.5 text-sm font-bold text-azul-800">{qtd} {qtd === 1 ? "entrega" : "entregas"}</span>
                      </li>
                    );
                  })}
                </ul>
              )}
            </Secao>

            <Secao titulo="Próximos prazos">
              {proximos.length === 0 ? <EstadoVazio titulo="Nenhum prazo futuro." /> : (
                <ul className="divide-y divide-cinza-200">
                  {proximos.map((a) => (
                    <li key={a.id} className="py-3 first:pt-0 last:pb-0">
                      <Link href={`/professor/atividades/${a.id}`} className="font-bold text-azul-800 hover:underline">{a.title}</Link>
                      <p className="text-sm text-cinza-600">{d.turmas.find((t) => t.id === a.class_id)?.name} · {dataHora(a.due_at)} ({prazoRelativo(a.due_at)})</p>
                    </li>
                  ))}
                </ul>
              )}
            </Secao>
          </div>

          <div className="mt-6">
            <Secao titulo="Participação por turma" acao={<Link href="/professor/turmas" className="link text-sm">Detalhes</Link>}>
              <ul className="space-y-5">
                {d.turmas.map((t) => {
                  const i = indicadoresDaTurma(d, t.id);
                  return (
                    <li key={t.id}>
                      <p className="mb-2 text-sm text-cinza-600"><span className="font-bold text-cinza-900">{t.name}</span> · {i.alunos.length} alunos · {i.atividades.length} atividades</p>
                      <Progresso valor={i.percentualConcluido} rotulo="Atividades entregues" />
                    </li>
                  );
                })}
              </ul>
            </Secao>
          </div>
        </>
      )}
    </>
  );
}
