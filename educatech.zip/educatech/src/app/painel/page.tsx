import { redirect } from "next/navigation";
import { getSessao } from "@/lib/auth";
import { rotaInicial } from "@/lib/rotas";
import { sair } from "@/lib/acoes/auth";
import { Aviso } from "@/components/ui";

// Encaminha cada pessoa para o painel do seu perfil.
export default async function Painel() {
  const s = await getSessao();
  if (!s) redirect("/entrar");
  if (!s.perfil) {
    return (
      <main className="mx-auto max-w-md p-8">
        <Aviso tom="erro" titulo="Não encontramos o perfil desta conta.">
          Saia e tente de novo. Se continuar, fale com a administração da escola.
        </Aviso>
        <form action={sair} className="mt-4"><button className="botao botao-primario">Sair da conta</button></form>
      </main>
    );
  }
  if (s.perfil.status !== "active") redirect("/pendente");
  redirect(rotaInicial(s.perfil.role));
}
