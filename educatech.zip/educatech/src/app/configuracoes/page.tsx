import type { Metadata } from "next";
import { exigirSessao } from "@/lib/auth";
import { sair } from "@/lib/acoes/auth";
import { atualizarPerfil } from "@/lib/acoes/conta";
import { alterarSenha } from "@/lib/acoes/auth";
import { rotuloPapel, rotuloSituacao, dataCurta } from "@/lib/formato";
import { AppShell } from "@/components/layout/shell";
import { Acessibilidade } from "@/components/layout/acessibilidade";
import { FormAcao, Campo, CampoSenha, BotaoEnviar } from "@/components/form";
import { Secao, TituloPagina } from "@/components/ui";

export const metadata: Metadata = { title: "Configurações" };

export default async function Configuracoes() {
  const { perfil, user } = await exigirSessao();
  return (
    <AppShell perfil={perfil}>
      <TituloPagina titulo="Configurações" descricao="Dados da conta, segurança e acessibilidade." />
      <div className="space-y-6">
        <Secao titulo="Minha conta">
          <dl className="mb-5 grid gap-3 text-sm sm:grid-cols-2">
            <div><dt className="font-bold">E-mail</dt><dd className="text-cinza-600">{user.email}</dd></div>
            <div><dt className="font-bold">Tipo de conta</dt><dd className="text-cinza-600">{rotuloPapel[perfil.role]}</dd></div>
            <div><dt className="font-bold">Situação</dt><dd className="text-cinza-600">{rotuloSituacao[perfil.status]}</dd></div>
            <div><dt className="font-bold">Conta criada em</dt><dd className="text-cinza-600">{dataCurta(perfil.created_at)}</dd></div>
          </dl>
          <FormAcao action={atualizarPerfil}>
            <Campo name="full_name" label="Nome completo" defaultValue={perfil.full_name} required autoComplete="name" />
            {perfil.role === "student" && (
              <Campo name="grade_label" label="Ano escolar" defaultValue={perfil.grade_label ?? ""} maxLength={40}
                ajuda="Ex.: 7º ano. Ajuda o Assistente a usar uma linguagem adequada. É a única informação escolar enviada à IA." />
            )}
            <BotaoEnviar aguarde="Salvando…">Salvar dados</BotaoEnviar>
          </FormAcao>
        </Secao>

        <Secao titulo="Alterar senha">
          <FormAcao action={alterarSenha}>
            <CampoSenha name="current" label="Senha atual" autoComplete="current-password" required />
            <CampoSenha name="password" label="Nova senha" autoComplete="new-password" required ajuda="Mínimo de 8 caracteres, com letras e números." />
            <CampoSenha name="confirm" label="Confirmar nova senha" autoComplete="new-password" required />
            <BotaoEnviar aguarde="Alterando…">Alterar senha</BotaoEnviar>
          </FormAcao>
        </Secao>

        <Secao titulo="Acessibilidade">
          <p className="mb-3 text-sm text-cinza-600">Estas preferências ficam salvas apenas neste navegador.</p>
          <Acessibilidade />
        </Secao>

        <Secao titulo="Sessão">
          <p className="mb-3 text-sm text-cinza-600">Ao sair, o acesso a esta conta é encerrado neste navegador.</p>
          <form action={sair}><button className="botao botao-secundario">Sair da conta</button></form>
        </Secao>
      </div>
    </AppShell>
  );
}
