import type { Metadata } from "next";
import Link from "next/link";
import { exigirSessao } from "@/lib/auth";
import { marcarNotificacaoLida, marcarTodasLidas } from "@/lib/acoes/conta";
import { dataHora } from "@/lib/formato";
import { caminhoSeguro } from "@/lib/rotas";
import { AppShell } from "@/components/layout/shell";
import { EstadoVazio, TituloPagina } from "@/components/ui";
import type { Notificacao } from "@/lib/tipos";

export const metadata: Metadata = { title: "Notificações" };

export default async function Notificacoes() {
  const { perfil, supabase } = await exigirSessao();
  const { data } = await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(50);
  const lista = (data ?? []) as Notificacao[];
  const naoLidas = lista.filter((n) => !n.read_at).length;

  return (
    <AppShell perfil={perfil}>
      <TituloPagina titulo="Notificações" descricao="Novas atividades, mudanças de prazo, devolutivas e avisos."
        acoes={naoLidas > 0 ? <form action={marcarTodasLidas}><button className="botao botao-secundario">Marcar todas como lidas</button></form> : undefined} />
      {lista.length === 0 ? (
        <EstadoVazio titulo="Você não tem notificações.">Quando houver novidades, elas aparecerão aqui.</EstadoVazio>
      ) : (
        <ul className="space-y-3">
          {lista.map((n) => (
            <li key={n.id} className={`painel flex flex-wrap items-start justify-between gap-3 p-4 ${n.read_at ? "" : "border-azul-200 bg-azul-50"}`}>
              <div>
                <p className="font-bold">{!n.read_at && <span className="sr-only">Não lida: </span>}{n.title}</p>
                {n.body && <p className="text-sm text-cinza-600">{n.body}</p>}
                <p className="mt-1 text-xs text-cinza-600">{dataHora(n.created_at)}</p>
              </div>
              <div className="flex gap-2">
                {n.link && <Link href={caminhoSeguro(n.link, "/painel")} className="botao botao-secundario botao-pequeno">Abrir</Link>}
                {!n.read_at && (
                  <form action={marcarNotificacaoLida}><input type="hidden" name="id" value={n.id} /><button className="botao botao-leve botao-pequeno">Marcar como lida</button></form>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </AppShell>
  );
}
