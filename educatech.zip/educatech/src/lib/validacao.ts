import { z } from "zod";
import type { Estado } from "./tipos";

/** Lê campos de texto de um FormData (campos ausentes viram ""). */
export function lerCampos(fd: FormData, nomes: string[]) {
  const o: Record<string, string> = {};
  for (const n of nomes) o[n] = String(fd.get(n) ?? "");
  return o;
}

/** Valida e devolve dados ou um Estado de erro com a mensagem de cada campo. */
export function validar<T extends z.ZodType>(
  schema: T, dados: unknown,
): { dados: z.infer<T>; erro?: undefined } | { dados?: undefined; erro: Estado } {
  const r = schema.safeParse(dados);
  if (r.success) return { dados: r.data };
  const erros: Record<string, string> = {};
  for (const i of r.error.issues) {
    const k = String(i.path[0] ?? "_");
    if (!(k in erros)) erros[k] = i.message;
  }
  return { erro: { ok: false, mensagem: "Confira os campos destacados.", erros } };
}

const texto = (min: number, max: number, nome: string) =>
  z.string().trim().min(min, `${nome}: escreva pelo menos ${min} caracteres.`).max(max, `${nome}: use no máximo ${max} caracteres.`);

export const email = z.string().trim().toLowerCase().min(1, "Informe o e-mail.").max(254).pipe(z.email("Digite um e-mail válido."));

export const senhaForte = z.string()
  .min(8, "A senha deve ter pelo menos 8 caracteres.")
  .max(72, "A senha pode ter no máximo 72 caracteres.")
  .regex(/[A-Za-z]/, "A senha deve ter pelo menos uma letra.")
  .regex(/\d/, "A senha deve ter pelo menos um número.");

export const esquemaEntrar = z.object({
  email,
  password: z.string().min(1, "Informe a senha.").max(200),
});

export const esquemaCadastro = z.object({
  full_name: texto(3, 120, "Nome"),
  email,
  account_type: z.enum(["student", "teacher"], { message: "Escolha o tipo de conta." }),
  code: z.string().trim().max(20, "Código inválido.").regex(/^[A-Za-z0-9]*$/, "O código tem apenas letras e números."),
  password: senhaForte,
  confirm: z.string(),
}).refine((d) => d.password === d.confirm, { path: ["confirm"], message: "As senhas não são iguais." });

export const esquemaRecuperar = z.object({ email });

export const esquemaNovaSenha = z.object({
  password: senhaForte,
  confirm: z.string(),
}).refine((d) => d.password === d.confirm, { path: ["confirm"], message: "As senhas não são iguais." });

export const esquemaAlterarSenha = z.object({
  current: z.string().min(1, "Informe a senha atual."),
  password: senhaForte,
  confirm: z.string(),
}).refine((d) => d.password === d.confirm, { path: ["confirm"], message: "As senhas não são iguais." });

export const esquemaPerfil = z.object({
  full_name: texto(3, 120, "Nome"),
  grade_label: z.string().trim().max(40, "Use no máximo 40 caracteres.").optional(),
});

export const uuid = z.string().uuid("Seleção inválida.");

export const esquemaAtividade = z.object({
  class_id: uuid,
  subject: texto(2, 60, "Matéria"),
  title: texto(3, 140, "Título"),
  instructions: texto(1, 5000, "Instruções"),
  kind: z.enum(["task", "written"], { message: "Escolha o tipo de atividade." }),
  due_at: z.string().min(1, "Informe o prazo."),
});

export const esquemaEntrega = z.object({
  activity_id: uuid,
  answer_text: z.string().trim().max(5000, "A resposta pode ter no máximo 5000 caracteres."),
});

export const esquemaDevolutiva = z.object({
  submission_id: uuid,
  comment: texto(1, 3000, "Comentário"),
  review_topic: z.string().trim().max(100, "Use no máximo 100 caracteres."),
});

export const esquemaAviso = z.object({
  class_id: uuid,
  title: texto(3, 140, "Título"),
  body: texto(1, 2000, "Mensagem"),
});

export const esquemaMeta = z.object({
  title: texto(3, 140, "Meta"),
  subject: z.string().trim().max(60, "Use no máximo 60 caracteres."),
  target_date: z.string().regex(/^(\d{4}-\d{2}-\d{2})?$/, "Data inválida."),
});

export const esquemaEscola = z.object({ name: texto(2, 120, "Nome da escola") });
export const esquemaTurma = z.object({
  school_id: uuid,
  name: texto(2, 80, "Nome da turma"),
  grade_label: z.string().trim().max(40, "Use no máximo 40 caracteres."),
});
export const esquemaCodigo = z.object({
  code: z.string().trim().min(1, "Informe o código.").max(20, "Código inválido.").regex(/^[A-Za-z0-9]+$/, "O código tem apenas letras e números."),
});
