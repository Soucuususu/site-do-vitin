import type { Atividade, Entrega } from "./tipos";

// O Brasil não usa horário de verão desde 2019, então -03:00 é seguro.
const FUSO = "America/Sao_Paulo";

export const dataHora = (iso: string) =>
  new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: FUSO }).format(new Date(iso));

export const dataLonga = (iso: string) =>
  new Intl.DateTimeFormat("pt-BR", { weekday: "long", day: "numeric", month: "long", timeZone: FUSO }).format(new Date(iso));

export const dataCurta = (iso: string) =>
  new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", timeZone: FUSO }).format(
    new Date(iso.length === 10 ? iso + "T12:00:00-03:00" : iso),
  );

/** "YYYY-MM-DD" no fuso de Brasília (para agrupar por dia). */
export const chaveDia = (iso: string) =>
  new Intl.DateTimeFormat("sv-SE", { timeZone: FUSO, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(iso));

/** Valor para <input type="datetime-local">. */
export function paraInputLocal(iso: string) {
  return new Intl.DateTimeFormat("sv-SE", {
    timeZone: FUSO, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).format(new Date(iso)).replace(" ", "T");
}

/** Converte o valor de <input type="datetime-local"> (horário de Brasília) para ISO. */
export function deInputLocal(valor: string) {
  const d = new Date(`${valor}:00-03:00`);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

export function prazoRelativo(iso: string) {
  const dias = Math.round((new Date(iso).getTime() - Date.now()) / 86_400_000);
  if (dias < -1) return `há ${-dias} dias`;
  if (dias === -1) return "ontem";
  if (dias === 0) return "hoje";
  if (dias === 1) return "amanhã";
  return `em ${dias} dias`;
}

export type Tom = "ok" | "alerta" | "erro" | "neutro" | "info";

/** Situação de uma atividade do ponto de vista do aluno. */
export function statusAtividade(a: Atividade, e?: Entrega): { rotulo: string; tom: Tom } {
  if (e) {
    if (e.status === "graded") return { rotulo: "Corrigida", tom: "ok" };
    const atrasada = new Date(e.submitted_at) > new Date(a.due_at);
    if (a.kind === "task") return { rotulo: atrasada ? "Concluída com atraso" : "Concluída", tom: atrasada ? "alerta" : "info" };
    return { rotulo: atrasada ? "Entregue com atraso" : "Entregue", tom: atrasada ? "alerta" : "info" };
  }
  if (new Date(a.due_at) < new Date()) return { rotulo: "Em atraso", tom: "erro" };
  return { rotulo: "Pendente", tom: "neutro" };
}

export const rotuloPapel = { student: "Aluno", teacher: "Professor", admin: "Administrador" } as const;
export const rotuloSituacao = { active: "Ativa", pending: "Aguardando aprovação", suspended: "Suspensa" } as const;
export const primeiroNome = (nome: string) => nome.trim().split(/\s+/)[0] ?? nome;
