// Tipos que representam as linhas do banco (ver supabase/migrations/0001_educatech.sql).

export type Papel = "student" | "teacher" | "admin";
export type Situacao = "active" | "pending" | "suspended";

export interface Perfil {
  id: string;
  full_name: string;
  email: string;
  role: Papel;
  status: Situacao;
  school_id: string | null;
  grade_label: string | null;
  created_at: string;
}

export interface Escola { id: string; name: string; invite_code: string; created_at: string }
export interface Turma { id: string; school_id: string; name: string; grade_label: string | null; join_code: string; created_at: string }
export interface MembroTurma { class_id: string; user_id: string; member_role: "student" | "teacher" }

export interface Atividade {
  id: string; class_id: string; teacher_id: string; subject: string; title: string;
  instructions: string; due_at: string; kind: "task" | "written"; created_at: string; updated_at: string;
}
export interface Entrega {
  id: string; activity_id: string; student_id: string; answer_text: string | null;
  status: "submitted" | "graded"; submitted_at: string;
}
export interface Devolutiva {
  id: string; submission_id: string; teacher_id: string; comment: string;
  review_topic: string | null; created_at: string; updated_at: string;
}
export interface Aviso { id: string; class_id: string; teacher_id: string; title: string; body: string; created_at: string }
export interface Notificacao { id: string; user_id: string; title: string; body: string | null; link: string | null; read_at: string | null; created_at: string }
export interface Meta { id: string; user_id: string; title: string; subject: string | null; target_date: string | null; done: boolean; created_at: string }
export interface EventoSeguranca { id: string; user_id: string | null; actor_id: string | null; event: string; meta: Record<string, unknown> | null; created_at: string }

/** Estado devolvido pelas ações de formulário (useActionState). */
export interface Estado {
  ok?: boolean;
  mensagem?: string;
  erros?: Record<string, string>;
}
