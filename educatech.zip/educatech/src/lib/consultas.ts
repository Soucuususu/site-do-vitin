import type { SupabaseClient } from "@supabase/supabase-js";
import type { Atividade, Aviso, Entrega, Turma } from "./tipos";

/** Tudo que o aluno enxerga (o RLS já filtra: só turmas e entregas dele). */
export async function carregarAluno(supabase: SupabaseClient, userId: string) {
  const [a, e, t] = await Promise.all([
    supabase.from("activities").select("*").order("due_at", { ascending: true }),
    supabase.from("submissions").select("*").eq("student_id", userId),
    supabase.from("classes").select("*"),
  ]);
  const atividades = (a.data ?? []) as Atividade[];
  const entregas = new Map(((e.data ?? []) as Entrega[]).map((x) => [x.activity_id, x]));
  const turmas = new Map(((t.data ?? []) as Turma[]).map((x) => [x.id, x]));
  return { atividades, entregas, turmas, erro: Boolean(a.error || e.error || t.error) };
}

export async function carregarAvisos(supabase: SupabaseClient, limite = 5) {
  const { data } = await supabase.from("announcements").select("*").order("created_at", { ascending: false }).limit(limite);
  return (data ?? []) as Aviso[];
}

export interface AlunoLite { id: string; full_name: string; grade_label: string | null }

/** Dados do professor (o RLS já limita às turmas e atividades dele). */
export async function carregarProfessor(supabase: SupabaseClient, userId: string) {
  const [c, m, a, s, f] = await Promise.all([
    supabase.from("classes").select("*").order("name"),
    supabase.from("class_members").select("*"),
    supabase.from("activities").select("*").eq("teacher_id", userId).order("due_at", { ascending: true }),
    supabase.from("submissions").select("*"),
    supabase.from("feedback").select("*").eq("teacher_id", userId),
  ]);
  const turmas = (c.data ?? []) as Turma[];
  const membros = ((m.data ?? []) as { class_id: string; user_id: string; member_role: string }[]).filter((x) => x.member_role === "student");
  const atividades = (a.data ?? []) as Atividade[];
  const entregas = (s.data ?? []) as Entrega[];
  const devolutivas = (f.data ?? []) as import("./tipos").Devolutiva[];

  const ids = [...new Set(membros.map((x) => x.user_id))];
  const { data: p } = ids.length ? await supabase.from("profiles").select("id,full_name,grade_label").in("id", ids) : { data: [] };
  const alunos = new Map(((p ?? []) as AlunoLite[]).map((x) => [x.id, x]));

  const alunosPorTurma = new Map<string, AlunoLite[]>();
  for (const x of membros) {
    const al = alunos.get(x.user_id);
    if (al) alunosPorTurma.set(x.class_id, [...(alunosPorTurma.get(x.class_id) ?? []), al]);
  }
  for (const [k, v] of alunosPorTurma) alunosPorTurma.set(k, v.sort((x, y) => x.full_name.localeCompare(y.full_name, "pt-BR")));

  return { turmas, alunosPorTurma, atividades, entregas, devolutivas, alunos, erro: Boolean(c.error || m.error || a.error || s.error) };
}

export type DadosProfessor = Awaited<ReturnType<typeof carregarProfessor>>;

/** Indicadores pedagógicos simples e transparentes. Não rotulam alunos nem fazem diagnóstico. */
export function indicadoresDaTurma(d: DadosProfessor, turmaId: string) {
  const alunos = d.alunosPorTurma.get(turmaId) ?? [];
  const atividades = d.atividades.filter((a) => a.class_id === turmaId);
  const idsAtiv = new Set(atividades.map((a) => a.id));
  const entregas = d.entregas.filter((e) => idsAtiv.has(e.activity_id));
  const esperado = atividades.length * alunos.length;
  const percentualConcluido = esperado ? Math.round((entregas.length / esperado) * 100) : 0;
  const quemEntregou = new Set(entregas.map((e) => e.student_id));
  const participacao = alunos.length ? Math.round((alunos.filter((x) => quemEntregou.has(x.id)).length / alunos.length) * 100) : 0;

  // Entregas em aberto: atividades com prazo vencido sem entrega, por aluno.
  const agora = new Date();
  const vencidas = atividades.filter((a) => new Date(a.due_at) < agora);
  const emAberto = alunos.map((al) => ({
    aluno: al,
    quantidade: vencidas.filter((a) => !entregas.some((e) => e.activity_id === a.id && e.student_id === al.id)).length,
  })).filter((x) => x.quantidade > 0).sort((x, y) => y.quantidade - x.quantidade);

  const entregaIds = new Set(entregas.map((e) => e.id));
  const contagem = new Map<string, number>();
  for (const dv of d.devolutivas) {
    if (dv.review_topic && entregaIds.has(dv.submission_id)) contagem.set(dv.review_topic, (contagem.get(dv.review_topic) ?? 0) + 1);
  }
  const topicos = [...contagem.entries()].sort((x, y) => y[1] - x[1]).slice(0, 5);

  return { alunos, atividades, entregas, percentualConcluido, participacao, emAberto, topicos };
}
