import { cache } from "react";
import { redirect } from "next/navigation";
import { criarClienteServidor } from "@/lib/supabase/server";
import { rotaInicial } from "@/lib/rotas";
import type { Papel, Perfil } from "@/lib/tipos";

/** Usuário logado + perfil (uma consulta por requisição). */
export const getSessao = cache(async () => {
  const supabase = await criarClienteServidor();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
  return { supabase, user, perfil: (data as Perfil | null) };
});

/**
 * Garante login, conta ativa e (opcionalmente) o papel certo.
 * Use no início de TODA página e ação privada. Esconder botões não é proteção:
 * a proteção real são estas verificações + as políticas RLS do banco.
 */
export async function exigirSessao(papel?: Papel) {
  const s = await getSessao();
  if (!s) redirect("/entrar");
  if (!s.perfil) redirect("/painel");
  if (s.perfil.status !== "active") redirect("/pendente");
  if (papel && s.perfil.role !== papel) redirect(rotaInicial(s.perfil.role));
  return { supabase: s.supabase, user: s.user, perfil: s.perfil };
}
