"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { criarClienteServidor } from "@/lib/supabase/server";
import { getSessao } from "@/lib/auth";
import { lerCampos, validar, esquemaEntrar, esquemaCadastro, esquemaRecuperar, esquemaNovaSenha, esquemaAlterarSenha } from "@/lib/validacao";
import type { Estado } from "@/lib/tipos";

async function urlDoSite() {
  const env = process.env.NEXT_PUBLIC_SITE_URL;
  if (env) return env.replace(/\/$/, "");
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const proto = h.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  return `${proto}://${host}`;
}

export async function entrar(_: Estado, fd: FormData): Promise<Estado> {
  const v = validar(esquemaEntrar, lerCampos(fd, ["email", "password"]));
  if (v.erro) return v.erro;

  const supabase = await criarClienteServidor();
  const { error } = await supabase.auth.signInWithPassword(v.dados);
  if (error) {
    if (error.code === "email_not_confirmed") {
      return { ok: false, mensagem: "Confirme seu e-mail antes de entrar. Procure a mensagem de confirmação na caixa de entrada (e no spam)." };
    }
    if (error.status === 429) return { ok: false, mensagem: "Muitas tentativas. Aguarde alguns minutos e tente de novo." };
    // Mensagem única: não revela se o e-mail existe.
    return { ok: false, mensagem: "E-mail ou senha incorretos." };
  }
  await supabase.rpc("log_security_event", { p_event: "login" });
  redirect("/painel");
}

export async function cadastrar(_: Estado, fd: FormData): Promise<Estado> {
  const v = validar(esquemaCadastro, lerCampos(fd, ["full_name", "email", "account_type", "code", "password", "confirm"]));
  if (v.erro) return v.erro;
  const d = v.dados;

  const supabase = await criarClienteServidor();

  if (d.code) {
    const { data: valido } = await supabase.rpc("check_signup_code", { p_code: d.code, p_kind: d.account_type });
    if (!valido) {
      return { ok: false, mensagem: "Confira os campos destacados.", erros: { code: d.account_type === "teacher" ? "Código da escola não encontrado." : "Código da turma não encontrado." } };
    }
  }

  const { data, error } = await supabase.auth.signUp({
    email: d.email,
    password: d.password,
    options: {
      // O papel NÃO é decidido aqui: o banco cria "aluno" ou "professor pendente".
      data: { full_name: d.full_name, account_type: d.account_type, code: d.code.toUpperCase() },
      emailRedirectTo: `${await urlDoSite()}/auth/callback`,
    },
  });

  if (error) {
    if (error.code === "user_already_exists" || error.code === "email_exists") {
      return { ok: false, mensagem: "Confira os campos destacados.", erros: { email: "Este e-mail já está cadastrado. Entre ou recupere a senha." } };
    }
    if (error.code === "weak_password") return { ok: false, mensagem: "Escolha uma senha mais forte.", erros: { password: "Senha muito fraca ou muito comum." } };
    if (error.status === 429) return { ok: false, mensagem: "Muitas tentativas. Aguarde alguns minutos e tente de novo." };
    return { ok: false, mensagem: "Não foi possível criar a conta agora. Tente novamente." };
  }
  // Com confirmação de e-mail ligada, e-mail repetido volta sem erro e sem identidades.
  if (data.user && data.user.identities && data.user.identities.length === 0) {
    return { ok: false, mensagem: "Confira os campos destacados.", erros: { email: "Este e-mail já está cadastrado. Entre ou recupere a senha." } };
  }
  if (data.session) redirect("/painel");
  redirect("/entrar?cadastro=ok");
}

export async function recuperarSenha(_: Estado, fd: FormData): Promise<Estado> {
  const v = validar(esquemaRecuperar, lerCampos(fd, ["email"]));
  if (v.erro) return v.erro;
  const supabase = await criarClienteServidor();
  await supabase.auth.resetPasswordForEmail(v.dados.email, {
    redirectTo: `${await urlDoSite()}/auth/callback?next=/redefinir-senha`,
  });
  // Resposta igual exista o e-mail ou não.
  return { ok: true, mensagem: "Se este e-mail estiver cadastrado, enviamos um link para criar uma nova senha. Abra o link no mesmo navegador." };
}

export async function redefinirSenha(_: Estado, fd: FormData): Promise<Estado> {
  const v = validar(esquemaNovaSenha, lerCampos(fd, ["password", "confirm"]));
  if (v.erro) return v.erro;
  const s = await getSessao();
  if (!s) return { ok: false, mensagem: "O link expirou. Peça um novo em “Esqueci minha senha”." };
  const { error } = await s.supabase.auth.updateUser({ password: v.dados.password });
  if (error) return { ok: false, mensagem: "Não foi possível alterar a senha. Escolha outra senha ou peça um novo link." };
  await s.supabase.rpc("log_security_event", { p_event: "password_reset" });
  redirect("/painel");
}

export async function alterarSenha(_: Estado, fd: FormData): Promise<Estado> {
  const v = validar(esquemaAlterarSenha, lerCampos(fd, ["current", "password", "confirm"]));
  if (v.erro) return v.erro;
  const s = await getSessao();
  if (!s) redirect("/entrar");
  const conferir = await s.supabase.auth.signInWithPassword({ email: s.user.email ?? "", password: v.dados.current });
  if (conferir.error) return { ok: false, mensagem: "Confira os campos destacados.", erros: { current: "Senha atual incorreta." } };
  const { error } = await s.supabase.auth.updateUser({ password: v.dados.password });
  if (error) return { ok: false, mensagem: "Não foi possível alterar a senha. Escolha uma senha diferente da atual." };
  await s.supabase.rpc("log_security_event", { p_event: "password_changed" });
  return { ok: true, mensagem: "Senha alterada com sucesso." };
}

export async function sair() {
  const supabase = await criarClienteServidor();
  await supabase.rpc("log_security_event", { p_event: "logout" });
  await supabase.auth.signOut();
  redirect("/");
}
