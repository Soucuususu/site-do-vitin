"use server";

import { revalidatePath } from "next/cache";
import { exigirSessao } from "@/lib/auth";
import { lerCampos, validar, esquemaPerfil, uuid } from "@/lib/validacao";
import type { Estado } from "@/lib/tipos";

export async function atualizarPerfil(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase, user } = await exigirSessao();
  const v = validar(esquemaPerfil, lerCampos(fd, ["full_name", "grade_label"]));
  if (v.erro) return v.erro;
  const { error } = await supabase.from("profiles")
    .update({ full_name: v.dados.full_name, grade_label: v.dados.grade_label || null }).eq("id", user.id);
  if (error) return { ok: false, mensagem: "Não foi possível salvar. Tente novamente." };
  revalidatePath("/", "layout");
  return { ok: true, mensagem: "Dados atualizados." };
}

export async function marcarNotificacaoLida(fd: FormData) {
  const { supabase } = await exigirSessao();
  const id = uuid.safeParse(String(fd.get("id") ?? ""));
  if (!id.success) return;
  await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("id", id.data);
  revalidatePath("/", "layout");
}

export async function marcarTodasLidas() {
  const { supabase, user } = await exigirSessao();
  await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("user_id", user.id).is("read_at", null);
  revalidatePath("/", "layout");
}
