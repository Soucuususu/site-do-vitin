"use server";

import { revalidatePath } from "next/cache";
import { exigirSessao } from "@/lib/auth";
import { lerCampos, validar, esquemaEntrega, esquemaMeta, esquemaCodigo, uuid } from "@/lib/validacao";
import type { Atividade, Estado } from "@/lib/tipos";

export async function enviarEntrega(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase, user } = await exigirSessao("student");
  const v = validar(esquemaEntrega, lerCampos(fd, ["activity_id", "answer_text"]));
  if (v.erro) return v.erro;
  const { activity_id, answer_text } = v.dados;

  // O RLS só devolve a atividade se ela pertence a uma turma do aluno.
  const { data: ativ } = await supabase.from("activities").select("*").eq("id", activity_id).maybeSingle();
  const atividade = ativ as Atividade | null;
  if (!atividade) return { ok: false, mensagem: "Atividade não encontrada." };
  if (atividade.kind === "written" && !answer_text) {
    return { ok: false, mensagem: "Escreva sua resposta antes de enviar.", erros: { answer_text: "Escreva sua resposta." } };
  }

  const { data: existente } = await supabase.from("submissions").select("id,status").eq("activity_id", activity_id).eq("student_id", user.id).maybeSingle();
  if (existente?.status === "graded") return { ok: false, mensagem: "Esta atividade já foi corrigida e não pode mais ser alterada." };

  const texto = answer_text || null;
  const { error } = existente
    ? await supabase.from("submissions").update({ answer_text: texto }).eq("id", existente.id)
    : await supabase.from("submissions").insert({ activity_id, student_id: user.id, answer_text: texto });
  if (error) return { ok: false, mensagem: "Não foi possível salvar agora. Tente novamente." };

  revalidatePath("/aluno", "layout");
  return { ok: true, mensagem: atividade.kind === "task" ? "Atividade marcada como concluída." : "Resposta enviada com sucesso." };
}

export async function entrarNaTurma(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase } = await exigirSessao("student");
  const v = validar(esquemaCodigo, lerCampos(fd, ["code"]));
  if (v.erro) return v.erro;
  const { error } = await supabase.rpc("join_class_by_code", { p_code: v.dados.code });
  if (error) return { ok: false, mensagem: "Confira os campos destacados.", erros: { code: "Código de turma inválido." } };
  revalidatePath("/aluno", "layout");
  return { ok: true, mensagem: "Pronto! Você entrou na turma." };
}

export async function criarMeta(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase, user } = await exigirSessao("student");
  const v = validar(esquemaMeta, lerCampos(fd, ["title", "subject", "target_date"]));
  if (v.erro) return v.erro;
  const { error } = await supabase.from("study_goals").insert({
    user_id: user.id, title: v.dados.title,
    subject: v.dados.subject || null, target_date: v.dados.target_date || null,
  });
  if (error) return { ok: false, mensagem: "Não foi possível salvar a meta. Tente novamente." };
  revalidatePath("/aluno/estudos");
  return { ok: true, mensagem: "Meta adicionada." };
}

export async function alternarMeta(fd: FormData) {
  const { supabase } = await exigirSessao("student");
  const id = uuid.safeParse(String(fd.get("id") ?? ""));
  if (!id.success) return;
  await supabase.from("study_goals").update({ done: fd.get("done") === "true" }).eq("id", id.data);
  revalidatePath("/aluno/estudos");
}

export async function excluirMeta(fd: FormData) {
  const { supabase } = await exigirSessao("student");
  const id = uuid.safeParse(String(fd.get("id") ?? ""));
  if (!id.success) return;
  await supabase.from("study_goals").delete().eq("id", id.data);
  revalidatePath("/aluno/estudos");
}
