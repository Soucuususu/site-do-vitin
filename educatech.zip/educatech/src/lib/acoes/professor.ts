"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { exigirSessao } from "@/lib/auth";
import { deInputLocal } from "@/lib/formato";
import { lerCampos, validar, esquemaAtividade, esquemaDevolutiva, esquemaAviso, uuid } from "@/lib/validacao";
import type { Estado } from "@/lib/tipos";

const CAMPOS_ATIVIDADE = ["class_id", "subject", "title", "instructions", "kind", "due_at"];

export async function criarAtividade(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase, user } = await exigirSessao("teacher");
  const v = validar(esquemaAtividade, lerCampos(fd, CAMPOS_ATIVIDADE));
  if (v.erro) return v.erro;
  const prazo = deInputLocal(v.dados.due_at);
  if (!prazo) return { ok: false, mensagem: "Confira os campos destacados.", erros: { due_at: "Prazo inválido." } };

  // O RLS recusa se a turma não for do professor.
  const { data, error } = await supabase.from("activities")
    .insert({ ...v.dados, due_at: prazo, teacher_id: user.id }).select("id").single();
  if (error || !data) return { ok: false, mensagem: "Não foi possível publicar. Verifique se a turma é sua e tente novamente." };
  revalidatePath("/professor", "layout");
  redirect(`/professor/atividades/${data.id}?publicada=1`);
}

export async function editarAtividade(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase } = await exigirSessao("teacher");
  const id = uuid.safeParse(String(fd.get("id") ?? ""));
  if (!id.success) return { ok: false, mensagem: "Atividade inválida." };
  const v = validar(esquemaAtividade.omit({ class_id: true }), lerCampos(fd, CAMPOS_ATIVIDADE.slice(1)));
  if (v.erro) return v.erro;
  const prazo = deInputLocal(v.dados.due_at);
  if (!prazo) return { ok: false, mensagem: "Confira os campos destacados.", erros: { due_at: "Prazo inválido." } };

  const { data, error } = await supabase.from("activities")
    .update({ ...v.dados, due_at: prazo }).eq("id", id.data).select("id");
  if (error || !data?.length) return { ok: false, mensagem: "Não foi possível salvar. Esta atividade não é sua ou não existe mais." };
  revalidatePath("/professor", "layout");
  redirect(`/professor/atividades/${id.data}?salva=1`);
}

export async function excluirAtividade(fd: FormData) {
  const { supabase } = await exigirSessao("teacher");
  const id = uuid.safeParse(String(fd.get("id") ?? ""));
  if (!id.success) return;
  await supabase.from("activities").delete().eq("id", id.data);
  revalidatePath("/professor", "layout");
  redirect("/professor/atividades?excluida=1");
}

export async function corrigirEntrega(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase, user } = await exigirSessao("teacher");
  const v = validar(esquemaDevolutiva, lerCampos(fd, ["submission_id", "comment", "review_topic"]));
  if (v.erro) return v.erro;
  const { submission_id, comment, review_topic } = v.dados;

  const { data: existente } = await supabase.from("feedback").select("id").eq("submission_id", submission_id).maybeSingle();
  const { error } = existente
    ? await supabase.from("feedback").update({ comment, review_topic: review_topic || null }).eq("id", existente.id)
    : await supabase.from("feedback").insert({ submission_id, teacher_id: user.id, comment, review_topic: review_topic || null });
  if (error) return { ok: false, mensagem: "Não foi possível salvar a devolutiva. Esta entrega é de uma atividade sua?" };

  const { error: erroStatus } = await supabase.from("submissions").update({ status: "graded" }).eq("id", submission_id);
  if (erroStatus) return { ok: false, mensagem: "A devolutiva foi salva, mas não foi possível marcar como corrigida." };

  revalidatePath("/professor", "layout");
  return { ok: true, mensagem: "Devolutiva salva e atividade marcada como corrigida." };
}

export async function criarAviso(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase, user } = await exigirSessao("teacher");
  const v = validar(esquemaAviso, lerCampos(fd, ["class_id", "title", "body"]));
  if (v.erro) return v.erro;
  const { error } = await supabase.from("announcements").insert({ ...v.dados, teacher_id: user.id });
  if (error) return { ok: false, mensagem: "Não foi possível publicar o aviso. Verifique se a turma é sua." };
  revalidatePath("/professor/avisos");
  return { ok: true, mensagem: "Aviso publicado. Os alunos da turma foram notificados." };
}

export async function excluirAviso(fd: FormData) {
  const { supabase } = await exigirSessao("teacher");
  const id = uuid.safeParse(String(fd.get("id") ?? ""));
  if (!id.success) return;
  await supabase.from("announcements").delete().eq("id", id.data);
  revalidatePath("/professor/avisos");
}
