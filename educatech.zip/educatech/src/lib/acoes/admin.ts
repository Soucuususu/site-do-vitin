"use server";

import { revalidatePath } from "next/cache";
import { exigirSessao } from "@/lib/auth";
import { lerCampos, validar, esquemaEscola, esquemaTurma, uuid } from "@/lib/validacao";
import type { Estado } from "@/lib/tipos";

/** Aprova, suspende ou reativa conta de professor ou aluno. Nunca de outro administrador. */
export async function alterarSituacao(fd: FormData) {
  const { supabase } = await exigirSessao("admin");
  const id = uuid.safeParse(String(fd.get("id") ?? ""));
  const status = String(fd.get("status") ?? "");
  if (!id.success || !["active", "suspended"].includes(status)) return;

  const { data: alvo } = await supabase.from("profiles").select("role").eq("id", id.data).maybeSingle();
  if (!alvo || alvo.role === "admin") return;
  await supabase.from("profiles").update({ status }).eq("id", id.data); // o banco também valida
  revalidatePath("/admin");
}

export async function criarEscola(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase } = await exigirSessao("admin");
  const v = validar(esquemaEscola, lerCampos(fd, ["name"]));
  if (v.erro) return v.erro;
  const { error } = await supabase.from("schools").insert({ name: v.dados.name });
  if (error) return { ok: false, mensagem: "Não foi possível criar a escola." };
  revalidatePath("/admin/estrutura");
  return { ok: true, mensagem: "Escola criada." };
}

export async function criarTurma(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase } = await exigirSessao("admin");
  const v = validar(esquemaTurma, lerCampos(fd, ["school_id", "name", "grade_label"]));
  if (v.erro) return v.erro;
  const { error } = await supabase.from("classes").insert({
    school_id: v.dados.school_id, name: v.dados.name, grade_label: v.dados.grade_label || null,
  });
  if (error) return { ok: false, mensagem: "Não foi possível criar a turma." };
  revalidatePath("/admin/estrutura");
  return { ok: true, mensagem: "Turma criada. Compartilhe o código dela com os alunos." };
}

export async function vincularProfessor(_: Estado, fd: FormData): Promise<Estado> {
  const { supabase } = await exigirSessao("admin");
  const classe = uuid.safeParse(String(fd.get("class_id") ?? ""));
  const prof = uuid.safeParse(String(fd.get("teacher_id") ?? ""));
  if (!classe.success || !prof.success) return { ok: false, mensagem: "Escolha um professor." };

  const { data: p } = await supabase.from("profiles").select("role,status").eq("id", prof.data).maybeSingle();
  if (!p || p.role !== "teacher" || p.status !== "active") {
    return { ok: false, mensagem: "Só é possível vincular professores com conta ativa." };
  }
  const { error } = await supabase.from("class_members").insert({ class_id: classe.data, user_id: prof.data, member_role: "teacher" });
  if (error) return { ok: false, mensagem: "Este professor já está nesta turma ou não foi possível vincular." };
  revalidatePath("/admin/estrutura");
  return { ok: true, mensagem: "Professor vinculado à turma." };
}

export async function desvincularProfessor(fd: FormData) {
  const { supabase } = await exigirSessao("admin");
  const classe = uuid.safeParse(String(fd.get("class_id") ?? ""));
  const prof = uuid.safeParse(String(fd.get("user_id") ?? ""));
  if (!classe.success || !prof.success) return;
  await supabase.from("class_members").delete().eq("class_id", classe.data).eq("user_id", prof.data).eq("member_role", "teacher");
  revalidatePath("/admin/estrutura");
}
