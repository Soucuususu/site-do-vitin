import type { Papel } from "./tipos";

export const rotaInicial = (papel: Papel) =>
  papel === "admin" ? "/admin" : papel === "teacher" ? "/professor" : "/aluno";

/** Só aceita caminhos internos (evita redirecionamento para sites externos). */
export const caminhoSeguro = (valor: string | null | undefined, padrao = "/painel") =>
  valor && valor.startsWith("/") && !valor.startsWith("//") && !valor.includes("\\") ? valor : padrao;
