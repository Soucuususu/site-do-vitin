# Roteiro de apresentação (Etapa 7) — EducaTech, Desafio Liga Jovem

Sugestão de 7 a 8 minutos. Adapte as palavras ao seu jeito; use dados reais da sua escola quando tiver (**não invente estatísticas**).

## 1. O problema (1 min)
Fale do que você observa na sua escola/turma: atividades e avisos espalhados em vários lugares, dificuldade de saber o que está pendente, alunos com dúvida sem ter com quem tirar fora da aula, professores sem uma visão simples de quem precisa de apoio. *(Se possível, cite 2 ou 3 relatos de colegas/professores que você ouviu de verdade.)*

## 2. A solução (1 min)
"O EducaTech reúne atividades, avisos e acompanhamento da turma em um só lugar e oferece um assistente de estudo com IA que ensina a pensar. Ele **apoia** o professor, não o substitui."

## 3. Demonstração ao vivo (3 min) — deixe as contas e a turma prontas antes
1. **Admin** aprova um professor e vincula à turma (mostra que professor não se "autopromove").
2. **Professor** publica uma atividade → mostra a notificação chegando no aluno.
3. **Aluno** envia a resposta e vê o calendário.
4. **Professor** corrige com comentário e "sugestão de revisão".
5. **Aluno** vê a devolutiva em "Meus estudos" e clica em *Estudar com o assistente*.
6. **Assistente**: faça uma pergunta e mostre que ele pergunta antes de dar a resposta. *(Diga claramente se está em modo demonstrativo ou com IA real.)*
7. Mostre o **ajuste de texto/alto contraste** e a tela no celular.

## 4. Segurança e privacidade (1 min)
- Regras de acesso no **banco de dados** (não só botões escondidos); testadas com cenários de ataque.
- Professor só entra após aprovação; admin só por controle no servidor.
- A chave da IA fica no servidor; a IA só recebe a pergunta e o ano escolar.
- Sem ranking nem notas públicas; indicadores sem rótulos.

## 5. O que já funciona e o que vem depois (1 min)
- **Já funciona:** contas e perfis, atividades (publicar, entregar, corrigir), avisos, notificações, calendário, metas, painel do professor, administração, assistente (demonstrativo ou real).
- **Próximos passos:** anexos e materiais baixáveis, modo offline (PWA), análise por questão, notificações por e-mail, piloto com uma turma e revisão de LGPD com a escola.

## 6. Perguntas que a banca pode fazer
| Pergunta | Resposta honesta |
|---|---|
| A IA pode errar? | Sim. O assistente admite incerteza, orienta confirmar com o professor e há aviso na tela. |
| Os alunos vão copiar respostas? | O assistente é instruído a incentivar o raciocínio antes de entregar a solução. Isso reduz, mas não elimina; o professor continua avaliando. |
| E os dados dos alunos (LGPD)? | Coleta mínima (nome, e-mail, ano escolar). A IA não recebe nome nem dados da escola. Para uso real com menores, falta o termo de consentimento dos responsáveis. |
| Funciona sem internet? | Ainda não. Está nos próximos passos. |
| Quanto custa manter? | Supabase e Vercel têm planos gratuitos para testes; a IA cobra por uso (há limite de perguntas por aluno). Confirme os preços atuais antes de afirmar valores. |
| Quem pode virar professor? | Só quem o administrador aprovar. |
