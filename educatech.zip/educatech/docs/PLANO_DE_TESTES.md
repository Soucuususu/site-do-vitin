# Plano de testes (Etapa 6)

## A. Testes automáticos das regras de acesso (banco de dados)

Os arquivos em `supabase/tests/` simulam o ambiente do Supabase em um PostgreSQL comum e tentam "atacar" as regras. Já foram executados com sucesso durante o desenvolvimento. Para repetir (precisa de PostgreSQL local):

```bash
createdb educatech_teste
psql educatech_teste -f supabase/tests/00_simular_supabase.sql
psql educatech_teste -f supabase/migrations/0001_educatech.sql
psql educatech_teste -f supabase/tests/01_testes_rls.sql
```

Resultado esperado (cada linha do teste imprime um título explicando o esperado):

| # | Cenário | Esperado |
|---|---|---|
| 1 | Cadastro pedindo `account_type: admin` | Vira **aluno** ativo |
| 2 | Professor ativo cria atividade na própria turma | Funciona |
| 3 | Professor cria atividade em turma que não é dele | Bloqueado |
| 4 | Professor pendente cria atividade | Bloqueado |
| 5 | Notificação de nova atividade | 1 por aluno da turma |
| 6 | Aluno vê atividades e perfis | Só as da sua turma; só ele e o professor |
| 7 | Aluno tenta virar admin / se ativar | Bloqueado |
| 8 | Aluno entrega; tenta marcar como corrigida; tenta entregar por outro aluno | Entrega ok; as outras duas bloqueadas |
| 9 | Aluno vê entrega de colega | 0 linhas |
| 10 | Aluno sem turma | Não vê nada; entra com código válido; código inválido falha |
| 11 | Professor corrige, tenta alterar resposta do aluno | Correção ok; alteração bloqueada |
| 11b | Devolutiva | Aluno dono vê; outro aluno não |
| 11c | Aluno edita entrega já corrigida | Nenhuma linha alterada |
| 12 | Admin aprova professor, tenta suspender a si mesmo, lê atividades | Aprova; bloqueado; 0 atividades |
| 13 | Professor suspenso | Perde acesso às atividades |
| 14 | Visitante sem login | Sem acesso às tabelas e às funções |
| 15 | Usuário comum e `security_events` / notificações | Não lê nem escreve eventos; só altera `read_at` |

## B. Testes manuais no aplicativo (faça com 3 contas: aluno, professor, admin)

**Autenticação**
- [ ] Cadastro com e-mail já usado mostra mensagem clara
- [ ] Senha curta, sem número ou diferente da confirmação é recusada
- [ ] Login errado mostra "E-mail ou senha incorretos."
- [ ] Mostrar/ocultar senha funciona com mouse e teclado
- [ ] Recuperar senha: link chega, nova senha funciona, a antiga deixa de funcionar
- [ ] Sair da conta encerra a sessão (voltar no navegador não mostra dados)

**Permissões (tente "burlar" pelo endereço)**
- [ ] Deslogado: abrir `/aluno`, `/professor`, `/admin` leva para o login
- [ ] Aluno abrindo `/professor` e `/admin` é redirecionado ao próprio painel
- [ ] Professor abrindo `/admin` é redirecionado
- [ ] Professor pendente só vê a tela "Aguardando aprovação"
- [ ] Professor A abrindo o endereço de uma atividade do professor B recebe "não encontrada"
- [ ] Aluno de outra turma abrindo o endereço de uma atividade recebe "não encontrada"
- [ ] Admin suspende um aluno: ele cai na tela "Conta suspensa" ao atualizar

**Funcionalidades**
- [ ] Professor publica atividade → aluno recebe notificação
- [ ] Aluno envia resposta; edita antes da correção; não edita depois
- [ ] Professor corrige com devolutiva e sugestão de revisão → aluno vê em Atividades e em Meus estudos
- [ ] Mudar o prazo gera notificação "Prazo alterado"
- [ ] Aviso do professor aparece no início do aluno
- [ ] Calendário mostra os prazos (teste mudar de mês)
- [ ] Metas de estudo: criar, concluir, reabrir, excluir

**Assistente**
- [ ] Sem chave: aparece "Modo demonstrativo" na página e no chat
- [ ] Com chave: responde, pergunta antes de entregar a solução, admite incerteza
- [ ] Mais de 15 perguntas em 10 minutos mostra a mensagem de limite
- [ ] Professor/admin não conseguem usar a rota (`403`)
- [ ] O navegador (aba Rede/Network) nunca mostra a chave da IA

**Celular e acessibilidade**
- [ ] Todas as telas em 360 px de largura: sem rolagem lateral (exceto a tabela do admin, que rola dentro da própria caixa)
- [ ] Menu abre e fecha no celular
- [ ] Navegar só com Tab: foco sempre visível; link "Ir para o conteúdo" funciona
- [ ] A+ até 150% e alto contraste mantêm tudo legível
- [ ] Teste com leitor de tela (NVDA no Windows, VoiceOver no iPhone/Mac, TalkBack no Android)
- [ ] Peça a um estudante e a um professor de verdade para executar as tarefas e anote as dificuldades

## C. O que foi verificado até agora

- ✅ Migração SQL aplicada em PostgreSQL 16 e os 15 cenários da seção A
- ✅ `tsc` sem erros e `next build` concluído
- ✅ Páginas públicas abrem; rotas privadas redirecionam ao login; a API do assistente responde 401 sem login; cabeçalhos de segurança presentes; aviso de "Falta configurar" aparece sem `.env`
- ⚠️ **Ainda não testado:** integração com um projeto Supabase real (e-mails, cadastro ponta a ponta), chamadas às APIs de IA reais e a aparência em navegadores/celulares reais. A seção B existe para fechar essas lacunas.
